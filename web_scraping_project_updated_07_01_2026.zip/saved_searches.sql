-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 06, 2026 at 04:53 AM
-- Server version: 10.6.19-MariaDB-cll-lve
-- PHP Version: 8.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmmtapp_properties`
--

-- --------------------------------------------------------

--
-- Table structure for table `saved_searches`
--

CREATE TABLE `saved_searches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `area` varchar(255) DEFAULT NULL,
  `min_price` decimal(15,2) DEFAULT NULL,
  `max_price` decimal(15,2) DEFAULT NULL,
  `min_bed` int(11) DEFAULT NULL,
  `max_bed` int(11) DEFAULT NULL,
  `min_bath` int(11) DEFAULT NULL,
  `max_bath` int(11) DEFAULT NULL,
  `property_type` varchar(255) DEFAULT NULL,
  `tenure_types` varchar(255) DEFAULT NULL,
  `must_have` varchar(255) DEFAULT NULL,
  `dont_show` varchar(255) DEFAULT NULL,
  `max_days_since_added` int(11) DEFAULT NULL,
  `updates_url` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `saved_searches`
--

INSERT INTO `saved_searches` (`id`, `area`, `min_price`, `max_price`, `min_bed`, `max_bed`, `min_bath`, `max_bath`, `property_type`, `tenure_types`, `must_have`, `dont_show`, `max_days_since_added`, `updates_url`, `created_at`, `updated_at`) VALUES
(14, 'Manchester, Greater Manchester', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.rightmove.co.uk/property-for-sale/find.html?searchLocation=Manchester%2C+Greater+Manchester&useLocationIdentifier=true&locationIdentifier=REGION%5E904&buy=For+sale&radius=0.0&_includeSSTC=on', '2026-01-01 14:07:21', '2026-01-02 15:43:44'),
(18, 'Main Southwest Land', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', NULL, 'https://www.rightmove.co.uk/property-for-sale/find.html?locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22c_%7DsHtyvRcfp%40%7Cyh%40uTnq%5DbpKv%7Dq%40zr%60%40%7CtrAlqJnnMdi%5BrqGlvNclLly%5C%7Dc%7C%40zzEmw%7D%40%7DbCs%7Ej%40w%7CScrl%40shWikSoi%5BhoFikQhyYpnFidP%22%7D&propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&channel=BUY&transactionType=BUY&displayLocationIdentifier=undefined&dontShow=newHome%2Cretirement%2CsharedOwnership&maxPrice=200000&index=0', '2026-01-01 15:58:41', '2026-01-01 15:58:41'),
(23, 'norwich', NULL, 250000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', NULL, 'https://www.rightmove.co.uk/property-for-sale/find.html?locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22scp%60I%7BytGatBliIeQ%60dCrNfxHySfhN%7Er%40%7ElE%7CvE%60wMnzDx%7BDhwEbyApxKja%40%7C%60%40or%40sA_fBahA%7BgLiQqjOq_BifOgrEmnMitBslCwoHqpAas%40%3FglB%60%7B%40jIqG%22%7D&propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=6&channel=BUY&transactionType=BUY&displayLocationIdentifier=undefined&dontShow=newHome%2Cretirement%2CsharedOwnership&maxPrice=250000&index=0', '2026-01-01 18:52:05', '2026-01-01 18:52:05'),
(29, 'Leeds 1', NULL, 180000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', NULL, 'https://www.rightmove.co.uk/property-for-sale/find.html?searchLocation=Leeds%2C+West+Yorkshire&useLocationIdentifier=true&locationIdentifier=REGION%5E787&radius=0.0&_includeSSTC=on&propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&channel=BUY&transactionType=BUY&displayLocationIdentifier=Leeds.html&dontShow=newHome%2Cretirement%2CsharedOwnership&maxPrice=180000&index=0', '2026-01-02 01:23:53', '2026-01-02 01:23:53'),
(30, 'Manchester, Greater Manchester', 50000.00, 90000.00, 2, 5, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?locationIdentifier=REGION%5E886&useLocationIdentifier=true&radius=0.0&sortType=2&minPrice=50000&maxPrice=90000&minBedrooms=2&maxBedrooms=5&includeSSTC=true&maxDaysSinceAdded=1', '2026-01-02 15:42:53', '2026-01-02 15:42:53'),
(33, 'Blackpool 1', NULL, 130000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, NULL, 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?searchLocation=Blackpool%2C+Lancashire&useLocationIdentifier=true&locationIdentifier=REGION%5E168&radius=0.0&_includeSSTC=on&propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&channel=BUY&transactionType=BUY&displayLocationIdentifier=Blackpool.html&maxPrice=130000&index=0', '2026-01-02 23:05:29', '2026-01-02 23:05:29'),
(34, 'sheffs', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&areaSizeUnit=sqft&channel=BUY&index=0&maxPrice=200000&locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22%7BizdIj_%60GwpGj%60RqfAflActHv_Coo%40xtAqA%7CcNx%7E%40r%7CHfjBrlCbeDv%7DCpyFtjD%7EuGrcAnmJ%3Ft%7CBmT%7CoBw_CfhBquEbDu_N%7BxA%7Bf%5EauB%7DzVevAaiGyxA%7Di%40c_CrGq%7CB%60%7B%40%7DbBl%7DA%7DgB%7CuGwt%40%7CuGnSen%40%22%7D&transactionType=BUY&displayLocationIdentifier=undefined&dontShow=newHome%2Cretirement%2CsharedOwnership', '2026-01-02 23:51:13', '2026-01-02 23:51:13'),
(35, 'worcester', NULL, 250000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&areaSizeUnit=sqft&channel=BUY&index=0&maxPrice=250000&locationIdentifier=REGION%5E1483&transactionType=BUY&displayLocationIdentifier=Worcester.html&dontShow=newHome%2Cretirement%2CsharedOwnership', '2026-01-03 00:06:13', '2026-01-03 00:06:13'),
(36, 'leicester', NULL, 150000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&sortType=2&areaSizeUnit=sqft&channel=BUY&index=0&maxPrice=150000&locationIdentifier=REGION%5E789&transactionType=BUY&displayLocationIdentifier=Leicester.html&dontShow=newHome%2Cretirement%2CsharedOwnership', '2026-01-03 00:13:06', '2026-01-03 00:13:06'),
(37, 'cov', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&dontShow=newHome%2Cretirement%2CsharedOwnership&channel=BUY&index=0&newHome=false&retirement=false&partBuyPartRent=false&sortType=2&areaSizeUnit=sqft&maxPrice=200000&locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22sob_IdkxHbmFduCfxJqG%60wCihCtbBwfFoIihCif%40waBieBkdEscEaiGgpA_mEwgBewBazBqpAs%7CB%3Fe%7DA%7Ci%40%7B%7BC%7CpCmInr%40gDzpChs%40byAnVpnBsA%7EnDef%40%7ElE%7CS%7EjF%7C%60%40dwBx_BrjDtp%40nT%7EbAslCiwB%7Di%40%22%7D&transactionType=BUY&displayLocationIdentifier=undefined', '2026-01-03 00:16:33', '2026-01-03 00:16:33'),
(38, 'north cov hink tam bed', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&dontShow=newHome%2Cretirement%2CsharedOwnership&channel=BUY&index=0&newHome=false&retirement=false&partBuyPartRent=false&sortType=2&areaSizeUnit=sqft&maxPrice=200000&locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22ijr_InrhFopDhoFk%7DDdcJi%5EhqEmIdcJwbAp%7CHq%7DGxs%5E%7Bz%40hxHeQz%60Id%5EfqEpwAx%7DCjlBre%40%7EaB%7BK%60bBglAbnK%7D_%5Bjk%40%7Di%40%7E%7EBmTnx%40a%7B%40%7CbA%7DpCrrAa%7B%40v%7D%40%7DpC%60n%40wfFtp%40gtUw%5Bo%60GiuAqwDomEm%60GgqCijBg%60AytAmk%40o%7BBbhAor%40imAse%40lx%40qG%22%7D&transactionType=BUY&displayLocationIdentifier=undefined', '2026-01-03 00:20:48', '2026-01-03 00:20:48'),
(39, 'rugby and that', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&dontShow=newHome%2Cretirement%2CsharedOwnership&channel=BUY&index=0&newHome=false&retirement=false&partBuyPartRent=false&sortType=2&areaSizeUnit=sqft&maxPrice=200000&locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22%7B%7Dv%7EHnfkE%7DbJhvIq%7CBlkHw%7D%40pjOlmAxbHdaDvfFvrJp%7CHb%7BE%3F%7CkOa%7EPdqEucAvgCvfFt%7DAv%7BOq%5EjyN%7BgNvbSgaEhdPebCf%7DWifEj%60R_bCncWlIbsOnaDtxJ%7EsI%7CzKprB%3F%7EtHi%7DLrhA_tHin%40irVipGwhh%40%3FwtLpcLuap%40%60TocWkn%40ouP_bDypNg%7BFutLw_HmkHqcJa%7B%40kvDpuEpmAglA%22%7D&transactionType=BUY&displayLocationIdentifier=undefined', '2026-01-03 00:48:18', '2026-01-03 00:48:18'),
(40, 'peterbro', NULL, 200000.00, NULL, NULL, NULL, NULL, 'detached,semi-detached,terraced,bungalow', NULL, NULL, 'newHome,retirement,sharedOwnership', 1, 'https://www.rightmove.co.uk/property-for-sale/find.html?propertyTypes=detached%2Csemi-detached%2Cterraced%2Cbungalow&dontShow=newHome%2Cretirement%2CsharedOwnership&channel=BUY&index=0&newHome=false&retirement=false&partBuyPartRent=false&sortType=2&areaSizeUnit=sqft&maxPrice=200000&locationIdentifier=USERDEFINEDAREA%5E%7B%22polylines%22%3A%22c%7Ee%60Ink%5DwyEzeMrNziK%7EuC%60iG%60_FjdElrA%7Ci%40toEia%40n%7DHkoFfs%40k%7DA%7BSa%7EPuyFwiVoaCytAivCha%40k%7BCtjD%7BvBbeIeDqnB%22%7D&transactionType=BUY&displayLocationIdentifier=undefined', '2026-01-03 01:34:30', '2026-01-03 01:34:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `saved_searches`
--
ALTER TABLE `saved_searches`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `saved_searches`
--
ALTER TABLE `saved_searches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
