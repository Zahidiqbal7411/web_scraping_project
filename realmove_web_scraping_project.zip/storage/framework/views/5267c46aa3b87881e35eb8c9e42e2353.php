<nav class="navbar">
    <div style="display: flex; align-items: center; gap: 1rem;">
        <button class="mobile-menu-btn" onclick="toggleMobileSidebar()" title="Toggle Menu">☰</button>
        <a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="navbar-user">
        <span class="user-name"><?php echo e(Auth::user() ? Auth::user()->name : 'Guest'); ?></span>
    </div>
</nav>

<?php /**PATH C:\xampp\htdocs\company_projects\laravel_projects\web_scraping_project\resources\views/layouts/header.blade.php ENDPATH**/ ?>