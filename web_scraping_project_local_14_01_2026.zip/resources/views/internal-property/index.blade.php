@extends('layouts.app')

@section('styles')
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: hsl(220, 85%, 50%);
            --primary-light: hsl(220, 85%, 96%);
            --secondary: hsl(200, 70%, 50%);
            --accent: hsl(340, 70%, 55%);
            --bg: hsl(0, 0%, 98%);
            --card-bg: hsl(0, 0%, 100%);
            --card-border: hsl(0, 0%, 88%);
            --text-primary: hsl(0, 0%, 15%);
            --text-secondary: hsl(0, 0%, 45%);
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.08);
            --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.12);
            --success: hsl(142, 70%, 45%);
            --error: hsl(0, 70%, 55%);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            color: var(--text-primary);
            min-height: 100vh;
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1.5rem;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .title {
            font-size: 2.25rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .sync-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-sm);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .sync-btn:hover {
            background: hsl(220, 85%, 45%);
            box-shadow: var(--shadow-md);
        }

        .sync-btn:active {
            transform: translateY(0);
        }

        .sync-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .sync-icon {
            width: 20px;
            height: 20px;
            animation: none;
        }

        .sync-btn:disabled .sync-icon {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* Stats Bar */
        .stats-bar {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 8px;
            padding: 1rem 1.25rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-sm);
            flex-wrap: wrap;
            gap: 1.5rem;
        }

        .stat-items-group {
            display: flex;
            gap: 2rem;
            align-items: center;
        }

        .sort-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .sort-select {
            padding: 0.5rem 1rem;
            border: 1px solid var(--card-border);
            border-radius: 6px;
            background: white;
            color: var(--text-primary);
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            outline: none;
            transition: border-color 0.2s;
        }

        .sort-select:focus {
            border-color: var(--primary);
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .stat-label {
            color: var(--text-secondary);
            font-size: 0.875rem;
            font-weight: 500;
        }

        .stat-value {
            color: var(--text-primary);
            font-size: 1.5rem;
            font-weight: 700;
        }

        /* Alert Messages */
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: none;
            align-items: center;
            gap: 1rem;
            animation: slideIn 0.3s ease-out;
        }

        .alert.active {
            display: flex;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid var(--success);
            color: hsl(142, 76%, 60%);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid var(--error);
            color: hsl(0, 84%, 75%);
        }

        /* Loading State */
        .loading {
            display: none;
            text-align: center;
            padding: 3rem;
            color: var(--text-secondary);
        }

        .loading.active {
            display: block;
        }

        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            display: none;
        }

        .empty-state.active {
            display: block;
        }

        .empty-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .empty-text {
            font-size: 1.125rem;
            color: var(--text-secondary);
            margin-bottom: 1.5rem;
        }

        /* Properties Grid - Responsive based on Sidebar */
        .properties-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
            margin-bottom: 2rem;
            overflow: hidden;
            width: 100%;
            max-width: 100%;
            transition: grid-template-columns 0.4s ease;
        }

        /* MAGIC: When sidebar is collapsed, make the grid 1-column so images are BIG */
        .sidebar-collapsed .properties-grid {
            grid-template-columns: 1fr;
            max-width: 1500px; /* Ultra-wide for premium feel */
            margin-left: 0; /* Align towards the left (sidebar side) */
            margin-right: auto;
            gap: 2rem;
        }

        .sidebar-collapsed .property-card {
            min-height: 650px;
            border-radius: 16px;
        }

        .sidebar-collapsed .property-sold-sidebar {
            flex: 0 0 750px; /* Much wider for high-detail view */
            background: #fbfbfb;
        }

        .sidebar-collapsed .property-image-wrapper,
        .sidebar-collapsed .image-nav,
        .sidebar-collapsed .image-slider-wrapper {
             aspect-ratio: 16/9; /* Widescreen for BIG effect */
        }

        /* Property Card - Split Layout */
        .property-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
            display: flex;
            flex-direction: row;
            align-items: stretch;
            min-height: 400px;
            max-width: 100%;
            box-sizing: border-box;
        }

        /* Left Side: Property Details */
        .property-main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--card-border);
            min-width: 0;
            overflow: hidden;
        }

        /* Right Side: Sold History */
        .property-sold-sidebar {
            flex: 0 0 320px;
            background: #fafafa;
            display: flex;
            flex-direction: column;
            border-left: 1px solid var(--card-border);
            overflow: hidden;
        }

        .property-image-section {
            position: relative;
            width: 100%;
            aspect-ratio: 4/3; /* Taller image as requested */
            overflow: hidden;
            background: #f0f0f0;
        }

        .property-info-section {
            padding: 1.25rem;
            flex: 1;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .discount-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: var(--success);
            color: white;
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            box-shadow: var(--shadow-sm);
            z-index: 5;
        }

        .address-house {
            color: var(--primary);
            font-weight: 700;
            font-size: 1.1rem;
            margin-right: 0.25rem;
        }

        .address-road {
            color: var(--text-primary);
            font-weight: 600;
        }

        /* Average Sold Price Display */
        .avg-sold-price {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 0;
            margin-top: 0.25rem;
            font-size: 0.85rem;
        }

        .avg-sold-price .avg-label {
            color: var(--text-secondary);
            font-weight: 500;
        }

        .avg-sold-price .avg-value {
            font-weight: 700;
            color: var(--success);
        }

        .avg-sold-price .avg-count {
            color: var(--text-secondary);
            font-size: 0.75rem;
        }

        /* Sold Sidebar Styles */
        .sold-sidebar-header {
            padding: 1.25rem 1.5rem;
            background: white;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .sold-sidebar-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        /* Clickable Sold History Title Link */
        .sold-sidebar-title-link {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .sold-sidebar-title-link:hover {
            color: var(--primary);
        }

        .sold-list-container {
            padding: 1rem;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            max-height: 600px;
        }
        
        /* Sold Card Style for Sidebar */
        .sold-item-card {
            background: white;
            border: 1px solid var(--card-border);
            border-radius: 10px;
            padding: 0.6rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.03);
            display: flex;
            gap: 0.75rem;
            transition: all 0.2s ease;
        }

        /* Default (Expanded Sidebar / 2-column grid) Photo Size */
        .sold-property-photo {
            flex: 0 0 90px;
            width: 90px;
            height: 65px;
            border-radius: 6px;
            overflow: hidden;
            background: #f0f0f0;
            border: 1px solid var(--card-border);
            transition: all 0.3s ease;
        }

        /* BIG Photo when Sidebar is Collapsed - High Definition Size */
        .sidebar-collapsed .sold-property-photo {
            flex: 0 0 260px;
            width: 260px;
            height: 180px;
            border-radius: 10px;
        }

        /* BIG Card Padding when Sidebar is Collapsed */
        .sidebar-collapsed .sold-item-card {
            padding: 1.5rem;
            gap: 2rem;
            border-radius: 14px;
        }

        .sold-property-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .sold-property-main {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .sold-property-type {
            font-weight: 700;
            font-size: 0.75rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.25rem;
        }

        .sold-property-location {
            font-size: 0.85rem; /* Smaller default for 2-column view */
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .sidebar-collapsed .sold-property-location {
            font-size: 1.15rem; /* Much larger and more prominent */
            margin-bottom: 1rem;
            font-weight: 700;
        }
        
        .sidebar-collapsed .sold-property-type {
            font-size: 0.95rem;
            margin-bottom: 0.75rem;
            color: var(--primary);
        }
        
        .sold-property-transactions {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        /* Sold Property Beds/Baths Display */
        .sold-beds-baths {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 0.5rem;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .sold-bed-item,
        .sold-bath-item {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .sold-bed-item svg,
        .sold-bath-item svg {
            color: var(--primary);
        }

        .sidebar-collapsed .sold-beds-baths {
            font-size: 0.95rem;
            gap: 1rem;
            margin-bottom: 0.75rem;
        }

        .sidebar-collapsed .sold-bed-item svg,
        .sidebar-collapsed .sold-bath-item svg {
            width: 18px;
            height: 18px;
        }

        .sold-tx-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.8rem; /* Smaller default */
        }

        .sidebar-collapsed .sold-tx-row {
            font-size: 0.95rem; /* Larger when sidebar collapsed */
            padding: 0.25rem 0;
        }

        .sold-tx-date {
            color: var(--text-secondary);
        }

        .sold-tx-price {
            font-weight: 700;
            color: var(--primary);
        }

        /* Sold Sidebar Footer */
        .sold-sidebar-footer {
            padding: 1rem;
            border-top: 1px solid var(--card-border);
            background: #f8f9fa;
        }

        /* Clickable Sold Card Link */
        .sold-item-card-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .sold-item-card-link:hover .sold-item-card {
            background: var(--card-bg);
            border-color: var(--secondary);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transform: translateY(-1px);
        }

        .sold-item-card-link:hover .sold-link-hint {
            color: var(--secondary);
        }

        /* Link Hint at bottom of sold card */
        .sold-link-hint {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 0.3rem;
            margin-top: 0.5rem;
            font-size: 0.65rem;
            color: var(--text-secondary);
            transition: color 0.2s ease;
        }

        .sold-link-hint svg {
            flex-shrink: 0;
        }

        /* Layout Overrides to fill screen but prevent overflow */
        .main-content {
            width: 100% !important;
            max-width: 100% !important;
            padding: 1rem !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            overflow-x: hidden !important;
            transition: all 0.3s ease;
        }
        
        .container {
            width: 100% !important;
            max-width: 100% !important;
            padding: 0 0.5rem !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            overflow: hidden !important;
        }

        /* Global fix for this page */
        body {
            overflow-x: hidden;
        }
        
        /* Hide old sold styles if they conflict */
        .sold-history-section { display: none; }

        /* Property Card */
        .property-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-sm);
            cursor: pointer;
            animation: fadeIn 0.3s ease-out;
        }

        .property-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Property Image */
        .property-image-wrapper {
            position: relative;
            aspect-ratio: 4/3;
            overflow: hidden;
            background: linear-gradient(135deg, rgba(0,0,0,0.3), rgba(0,0,0,0.5));
        }

        .property-image-slider {
            position: relative;
            height: 100%;
        }

        .property-image-container {
            display: flex;
            transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            height: 100%;
        }

        .property-image {
            min-width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: all 0.3s;
            z-index: 2;
        }

        .property-card:hover .image-nav {
            opacity: 1;
        }

        .image-nav:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-50%) scale(1.1);
        }

        .image-nav.prev {
            left: 0.5rem;
        }

        .image-nav.next {
            right: 0.5rem;
        }

        .image-counter {
            position: absolute;
            bottom: 0.75rem;
            right: 0.75rem;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            z-index: 2;
        }

        .property-badge {
            position: absolute;
            top: 0.75rem;
            left: 0.75rem;
            background: var(--accent);
            color: white;
            padding: 0.375rem 0.875rem;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            z-index: 2;
        }
        
        /* Image Slider Wrapper */
        .image-slider-wrapper {
            position: relative;
            width: 100%;
            aspect-ratio: 4/3;
            overflow: hidden;
            background: #f0f0f0;
        }
        
        .image-slides {
            position: relative;
            width: 100%;
            height: 100%;
        }
        
        .image-slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.5s ease;
        }
        
        .image-slide.active {
            opacity: 1;
        }
        
        .image-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .nav-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.8);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 1.5rem;
            color: #333;
            opacity: 0;
            transition: all 0.3s;
            z-index: 10;
        }
        
        .property-card:hover .nav-arrow {
            opacity: 1;
        }
        
        .nav-arrow:hover {
            background: white;
            transform: translateY(-50%) scale(1.1);
        }
        
        .nav-arrow.left {
            left: 0.75rem;
        }
        
        .nav-arrow.right {
            right: 0.75rem;
        }

        /* Property Details */
        .property-details {
            padding: 1.5rem;
        }

        .property-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .property-reduced {
            color: var(--accent);
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .property-address {
            color: var(--text-primary);
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            line-height: 1.4;
        }

        .property-features {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1rem;
            color: var(--text-secondary);
            font-size: 0.875rem;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }

        .feature-icon {
            width: 16px;
            height: 16px;
        }

        .property-type {
            color: var(--text-secondary);
            font-size: 0.875rem;
            margin-top: 0.75rem;
            padding-top: 0.75rem;
            border-top: 1px solid var(--card-border);
        }
        
        /* Property Info Section */
        .property-info-section {
            padding: 1.25rem;
        }
        
        .property-address-title {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0 0 0.75rem 0;
            line-height: 1.4;
        }
        
        .property-price-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .price-amount {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .info-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            font-size: 0.75rem;
            color: var(--text-secondary);
            cursor: help;
        }
        
        .reduced-date {
            font-size: 0.875rem;
            color: var(--accent);
            margin-bottom: 1rem;
        }
        
        /* Property Details Grid */
        .property-details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--card-border);
        }
        
        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .detail-label {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .detail-value {
            display: flex;
            align-items: center;
            gap: 0.375rem;
            font-size: 0.875rem;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .detail-icon {
            width: 16px;
            height: 16px;
            color: var(--text-secondary);
        }
        
        .detail-item.skeleton .detail-value {
            color: var(--text-secondary);
            font-style: italic;
        }

        /* Layout Overrides to fill screen */
        .main-content {
            width: 100% !important;
            padding: 1.5rem !important;
            box-sizing: border-box !important;
        }
        
        .container {
            width: 100% !important;
            max-width: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        /* Sold Property History */
        .sold-history-section {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px dashed var(--card-border);
            background: #fafafa;
            /* Removed negative margins to prevent horizontal scroll */
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 0.5rem;
        }

        .sold-history-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sold-count-badge {
            background: var(--secondary);
            color: white;
            font-size: 0.75rem;
            padding: 0.15rem 0.5rem;
            border-radius: 6px;
            font-weight: 600;
        }

        .sold-properties-container {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            max-height: 400px;
            overflow-y: auto;
            padding-right: 0.5rem;
            /* Ensure no horizontal scroll inside */
            overflow-x: hidden;
        }
        
        .sold-property-card {
            background: white;
            border: 1px solid var(--card-border);
            border-radius: 8px;
            padding: 1rem;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
            transition: all 0.2s;
        }
        
        .sold-property-card:hover {
            border-color: var(--secondary);
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .sold-property-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.75rem;
        }
        
        .sold-property-type {
            font-weight: 700;
            color: var(--text-primary);
            font-size: 0.95rem;
        }
        
        .sold-property-price {
            font-weight: 700;
            color: var(--primary);
            font-size: 1.1rem;
        }

        .sold-details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
            margin-bottom: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px dashed var(--card-border);
        }
        
        /* Re-use detail-item styles but smaller */
        .sold-details-grid .detail-label {
            font-size: 0.65rem;
        }
        
        .sold-details-grid .detail-value {
            font-size: 0.8rem;
        }
        
        .sold-transactions-list {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
        }
        
        .sold-transaction-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.8rem;
            color: var(--text-secondary);
            padding: 0.25rem 0;
            border-bottom: 1px dotted var(--card-border);
        }
        
        .sold-transaction-item:last-child {
            border-bottom: none;
        }
        
        .sold-transaction-price {
            font-weight: 600;
            color: var(--text-primary);
        }

        /* Property URL */
        .property-url-wrapper {
            margin-bottom: 0.75rem;
        }

        .property-url-display {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .property-url {
            font-size: 0.75rem;
            color: var(--text-secondary);
            word-break: break-all;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            flex: 1;
            min-width: 0;
        }

        .property-url a {
            color: var(--secondary);
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .property-url a:hover {
            color: var(--primary);
            text-decoration: underline;
        }

        .url-edit-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.25rem;
            color: var(--text-secondary);
            transition: color 0.2s ease;
            flex-shrink: 0;
        }

        .url-edit-btn:hover {
            color: var(--primary);
        }

        .property-url-edit {
            display: none;
        }

        .property-url-edit.active {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .property-url-edit input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--card-border);
            border-radius: 4px;
            font-size: 0.75rem;
            font-family: inherit;
        }

        .property-url-edit input:focus {
            outline: none;
            border-color: var(--primary);
        }

        .url-edit-actions {
            display: flex;
            gap: 0.5rem;
        }

        .url-save-btn, .url-cancel-btn {
            padding: 0.375rem 0.75rem;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .url-save-btn {
            background: var(--success);
            color: white;
            border: none;
        }

        .url-save-btn:hover {
            background: hsl(142, 70%, 40%);
        }

        .url-cancel-btn {
            background: transparent;
            color: var(--text-secondary);
            border: 1px solid var(--card-border);
        }

        .url-cancel-btn:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        /* Search URL Bar */
        .search-url-bar {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 8px;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-sm);
            display:none;
        }

        .search-url-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
        }

        .search-url-display {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .search-url-text {
            flex: 1;
            font-size: 0.875rem;
            color: var(--secondary);
            word-break: break-all;
            overflow-wrap: break-word;
            line-height: 1.5;
        }

        .search-url-text a {
            color: inherit;
            text-decoration: none;
        }

        .search-url-text a:hover {
            text-decoration: underline;
        }

        .search-url-edit-section {
            display: none;
        }

        .search-url-edit-section.active {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .search-url-edit-section input {
            width: 100%;
            padding: 0.625rem;
            border: 1px solid var(--card-border);
            border-radius: 6px;
            font-size: 0.875rem;
            font-family: inherit;
        }

        .search-url-edit-section input:focus {
            outline: none;
            border-color: var(--primary);
        }

        .search-url-actions {
            display: flex;
            gap: 0.5rem;
        }

        .search-url-btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .search-url-btn.save {
            background: var(--success);
            color: white;
            border: none;
        }

        .search-url-btn.save:hover {
            background: hsl(142, 70%, 40%);
        }

        .search-url-btn.cancel {
            background: transparent;
            color: var(--text-secondary);
            border: 1px solid var(--card-border);
        }

        .search-url-btn.cancel:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        .property-actions {
            display: flex;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .action-btn {
            flex: 1;
            padding: 0.75rem;
            border-radius: 8px;
            border: 1px solid var(--card-border);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            text-align: center;
        }

        .action-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--primary);
        }

        .action-btn.primary {
            background: var(--primary);
            color: white;
            border: none;
        }

        .action-btn.primary:hover {
            background: hsl(220, 85%, 45%);
        }
        
        /* View Button */
        .view-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
            padding: 0.875rem;
            margin-top: 1rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
        }
        
        .view-btn:hover {
            background: hsl(220, 85%, 45%);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        
        .view-btn svg {
            flex-shrink: 0;
        }

        
        /* Import Progress Bar */
        .import-progress-container {
            background: linear-gradient(135deg, var(--card-bg), #f8f9fa);
            border: 2px solid var(--primary);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            display: none;
            animation: slideIn 0.3s ease-out;
        }
        
        .import-progress-container.active {
            display: block;
        }
        
        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .progress-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .progress-title::before {
            content: '⚡';
            font-size: 1.3rem;
        }
        
        .progress-stats {
            font-size: 0.95rem;
            color: var(--text-secondary);
            font-weight: 600;
        }
        
        .progress-stats span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .progress-bar-wrapper {
            position: relative;
            width: 100%;
            height: 40px;
            background: rgba(0, 0, 0, 0.05);
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 1rem;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            width: 0%;
            transition: width 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .progress-bar-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
                
        .progress-percentage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--text-primary);
            z-index: 2;
            text-shadow: 0 1px 2px rgba(255,255,255,0.8);
        }
        
        .progress-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.75rem;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }
        
        .progress-details > span:first-child {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .progress-speed {
            color: var(--success);
            font-weight: 600;
        }
        
        .progress-speed::before {
            content: '⚡ ';
        }
        
        .progress-eta {
            color: var(--secondary);
            font-weight: 600;
        }
        
        .progress-eta::before {
            content: '⏱ ';
        }

        .sold-sidebar-header {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            background: #f8f9fa;
        }

        .sold-sidebar-left {
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .sold-sidebar-title, .sold-sidebar-title-link {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--text-main);
            white-space: nowrap;
        }

        .sold-sidebar-title-link {
            color: var(--primary);
            text-decoration: none;
            transition: color 0.2s;
        }

        .sold-sidebar-title-link:hover {
            color: var(--secondary);
        }

        /* Sold Property Import Button (Header version) */
        .sold-header-import-btn {
            background: white;
            color: var(--primary);
            border: 1px solid var(--primary);
            padding: 0.25rem 0.6rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            flex-shrink: 0;
        }

        .sold-header-import-btn:hover {
            background: var(--primary);
            color: white;
        }

        .sold-header-import-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            background: #eee;
            border-color: #ccc;
            color: #666;
        }

        .sold-header-import-btn .spinner-sm {
            width: 10px;
            height: 10px;
            border: 2px solid currentColor;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            display: none;
        }

        .sold-header-import-btn.loading .spinner-sm {
            display: inline-block;
        }

        .sold-header-import-btn.loading .btn-text {
            display: none;
        }

        @media (max-width: 768px) {
            .title {
                font-size: 1.75rem;
            }

            .properties-grid {
                grid-template-columns: 1fr;
            }

            .stats-bar {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .progress-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }
            
            .progress-details {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
@endsection

@section('content')
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1 class="title">
                @if(isset($search))
                    Properties in {{ str_replace('+', ' ', urldecode($search->area)) }}
                @else
                    All Imported Properties
                @endif
            </h1>
            {{-- Hidden as per user request --}}
            @if(isset($search))
            <div style="display: none; gap: 1rem;">
                <button class="sync-btn" id="headerImportSoldBtn" style="display: none; background: var(--secondary);">
                    <svg class="sync-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Import Sold Properties
                </button>
                <button class="sync-btn" id="syncBtn">
                    <svg class="sync-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path>
                    </svg>
                    Import Properties
                </button>
            </div>
            @endif
        </div>

        @if(isset($search) && $search->updates_url)
        <!-- Search URL Bar -->
        <div class="search-url-bar">
            <div class="search-url-label">Search URL</div>
            <div class="search-url-display" id="searchUrlDisplay">
                <div class="search-url-text" title="{{ $search->updates_url }}">
                    <a href="{{ $search->updates_url }}" target="_blank" id="searchUrlLink">{{ $search->updates_url }}</a>
                </div>
                <button class="url-edit-btn" onclick="toggleSearchUrlEdit()" title="Edit URL">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                              d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                    </svg>
                </button>
            </div>
            <div class="search-url-edit-section" id="searchUrlEdit">
                <input type="text" id="searchUrlInput" value="{{ $search->updates_url }}" placeholder="Enter Rightmove URL">
                <div class="search-url-actions">
                    <button class="search-url-btn save" onclick="saveSearchUrl()">Save</button>
                    <button class="search-url-btn cancel" onclick="cancelSearchUrlEdit()">Cancel</button>
                </div>
            </div>
        </div>
        @endif

        <!-- Stats Bar -->
        <div class="stats-bar" id="statsBar" style="display: none;">
            <div class="stat-items-group">
                <div class="stat-item">
                    <span class="stat-label">Total Properties</span>
                    <span class="stat-value" id="totalCount">0</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Loaded</span>
                    <span class="stat-value" id="loadedCount">0</span>
                </div>
            </div>
            
            <div class="sort-group">
                <label for="sortSelect" class="stat-label">Sort by:</label>
                <select id="sortSelect" class="sort-select" onchange="handleSortChange()">
                    <option value="default">Default</option>
                    <option value="price_low">Price (Low to High)</option>
                    <option value="price_high">Price (High to Low)</option>
                    <option value="avg_price_low">Avg Sold Price (Low to High)</option>
                    <option value="avg_price_high">Avg Sold Price (High to Low)</option>
                    <option value="discount_high">Largest Discount %</option>
                    <option value="discount_low">Smallest Discount %</option>
                    <option value="road_asc">Road Name (A-Z)</option>
                </select>
            </div>
        </div>

        <!-- Limit Warning Banner (Persistent) -->
        <div id="limitWarning" style="display: none; background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; padding: 1rem; margin-bottom: 1.5rem; border-radius: 8px; flex-direction: row; align-items: flex-start; gap: 1rem;">
            <svg style="width: 24px; height: 24px; flex-shrink: 0;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <div style="flex: 1;">
                <h4 style="margin: 0 0 0.5rem 0; font-weight: 600; font-size: 1rem;">Source Website Limit Reached (42 Pages)</h4>
                <p style="margin: 0; font-size: 0.95rem; line-height: 1.5;">
                    You have retrieved <strong>100%</strong> of the properties that Rightmove allows you to view for this single search. 
                    The remaining <strong id="limitHiddenCount">0</strong> properties are hidden by the source website (Rightmove restricts *any* search to 42 pages).
                </p>
                <div style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid #e6dbb9;">
                    <strong>How to get the rest?</strong> <br>
                    Use the <b>Split Search Strategy</b>: Create multiple smaller searches using <b>Price Ranges</b> (e.g., Search 1: £0-£200k, Search 2: £200k-£500k). 
                    Run each search separately to bypass the 1000-property limit.
                </div>
            </div>
        </div>

        <!-- Alerts -->
        <div class="alert alert-success" id="successAlert"></div>
        <div class="alert alert-error" id="errorAlert"></div>

        <!-- Import Progress Bar -->
        <!-- Import Progress Bar - HIDDEN AS REQUESTED -->
        <div class="import-progress-container" id="importProgress" style="display: none !important;">
            <div class="progress-header">
                <span class="progress-title" id="progressTitle">Importing Properties</span>
                <span class="progress-stats" id="progressStats">Chunk <span id="currentChunk">0</span> of <span id="totalChunks">0</span></span>
            </div>
            <div class="progress-status-message" id="progressStatusMessage" style="display: none; padding: 0.75rem; margin-bottom: 1rem; background: linear-gradient(135deg, #fef3c7, #fde68a); border-radius: 8px; color: #92400e; font-size: 0.9rem; text-align: center;">
                <span class="status-icon" style="margin-right: 0.5rem;">⏳</span>
                <span id="statusMessageText">Waiting for queue worker to start...</span>
            </div>
            <div class="progress-bar-wrapper">
                <div class="progress-bar-fill" id="progressBarFill"></div>
                <span class="progress-percentage" id="progressPercentage">0%</span>
            </div>
            <div class="progress-details">
                <span><span id="propertiesImported">0</span> of <span id="totalProperties">0</span> properties</span>
                <span class="progress-speed" id="importSpeed"></span>
                <span class="progress-eta" id="importETA"></span>
            </div>
        </div>

        <!-- Loading State - FROM DATABASE -->
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p id="loadingText">Loading properties from database...</p>
        </div>
        
        <!-- Loading State - FROM SOURCE WEBSITE -->
        <div class="loading" id="importLoading" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));">
            <div class="spinner" style="border-top-color: #10b981;"></div>
            <p style="color: #10b981; font-weight: 600;">Fetching data from source website...</p>
            
            <!-- Simple Count Display -->
            <div id="simpleImportStats" style="margin-top: 0.8rem; font-weight: 700; font-size: 1.1rem; color: #047857;">
                <span id="simpleLoadedCount">0</span> / <span id="simpleTotalCount">...</span> properties
            </div>
            
            <p style="color: var(--text-secondary); font-size: 0.8rem; margin-top: 0.5rem;">This may take several minutes for large datasets</p>
        </div>

        <!-- Empty State -->
        <div class="empty-state active" id="emptyState">
            <div class="empty-icon">📂</div>
            <p class="empty-text">No properties found in database</p>
            <p style="color: var(--text-secondary); font-size: 0.875rem;">Import properties from a specific filter to see them here</p>
        </div>

        <!-- Properties Grid -->
        <div class="properties-grid" id="propertiesGrid"></div>
    </div> <!-- End of container -->
@endsection

@section('scripts')
    <script>
        // Global fetch timeout wrapper to prevent timeout errors on long-running imports
        const originalFetch = window.fetch;
        window.fetch = function(...args) {
            // If no timeout specified, add 30 minute timeout for all requests
            const config = args[1] || {};
            if (!config.signal) {
                const controller = new AbortController();
                const timeout = setTimeout(() => {
                    console.log("Request taking longer than 30 minutes, but still running...");
                    // Don't actually abort, just log
                }, 1800000); // 30 minutes
                
                config.signal = controller.signal;
                args[1] = config;
                
                return originalFetch(...args).finally(() => clearTimeout(timeout));
            }
            return originalFetch(...args);
        };
        
        window.searchContext = @json($search ?? null);
    </script>
    <script>
        
        // State
        let currentSlide = 0;
        let propertyData = null;
        let propertyUrls = [];
        let loadedProperties = [];
        let currentPage = 1;
        const itemsPerPage = 10; // Show 10 properties per page
        
        // Image slider state
        let currentImageIndexes = {};
        
        // Elements
        const statsBar = document.getElementById('statsBar');
        const successAlert = document.getElementById('successAlert');
        const errorAlert = document.getElementById('errorAlert');
        const loading = document.getElementById('loading');
        const emptyState = document.getElementById('emptyState');
        const propertiesGrid = document.getElementById('propertiesGrid');
        const totalCount = document.getElementById('totalCount');
        const loadedCount = document.getElementById('loadedCount');
        const syncBtn = document.getElementById('syncBtn');
        
        // Progress bar elements
        const importProgress = document.getElementById('importProgress');
        const progressBarFill = document.getElementById('progressBarFill');
        const progressPercentage = document.getElementById('progressPercentage');
        const currentChunkEl = document.getElementById('currentChunk');
        const totalChunksEl = document.getElementById('totalChunks');
        const propertiesImported = document.getElementById('propertiesImported');
        const totalPropertiesEl = document.getElementById('totalProperties');
        const importSpeed = document.getElementById('importSpeed');
        const importETA = document.getElementById('importETA');
        
        // Search context from server
        window.searchContext = {!! json_encode($search ?? null) !!};

        // Import button handler
        if (syncBtn) {
            syncBtn.addEventListener('click', async () => {
                await importAllProperties(true);
            });
        }

        const headerImportSoldBtn = document.getElementById('headerImportSoldBtn');
        if (headerImportSoldBtn) {
            headerImportSoldBtn.addEventListener('click', async () => {
                await fetchRemainingSoldData();
            });
        }

        // Load properties on startup
        document.addEventListener('DOMContentLoaded', async () => {
            // Check for any active background imports first
            await checkActiveImports();
            
            // On page load, try to load complete property data from database
            await loadFromDatabaseOnStartup();
        });

        // Check for any active background imports
        async function checkActiveImports() {
            try {
                const response = await fetch('/internal-properties/import/sessions', {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                
                if (!response.ok) return;
                
                const data = await response.json();
                if (data.success && data.sessions && data.sessions.length > 0) {
                    // Find most recent active session
                    const activeSession = data.sessions.find(s => s.is_running);
                    
                    if (activeSession) {
                        console.log(`🔍 Active import found (Session #${activeSession.id}). Restoring banner...`);
                        showImportStartedBanner(activeSession.id);
                    }
                }
            } catch (error) {
                console.error('Error checking active imports:', error);
            }
        }

        // Load full property data from database on page startup
        async function loadFromDatabaseOnStartup() {
            try {
                loading.classList.add('active');
                emptyState.classList.remove('active');
                
                // Load first page
                const data = await loadPropertiesPage(1);
                
                if (!data || !data.properties || data.properties.length === 0) {
                    loading.classList.remove('active');
                    emptyState.classList.add('active');
                    statsBar.style.display = 'none';
                    console.log('No properties in database. Click Import to fetch from source.');
                    return;
                }
                
                // Show stats bar and initial data
                statsBar.style.display = 'flex';
                
                // If loaded is more than total (due to background imports), sync them for visual consistency
                const displayTotal = Math.max(data.total, data.properties.length);
                totalCount.textContent = displayTotal;
                loadedCount.textContent = data.properties.length;
                
                loadedProperties = data.properties;
                propertyUrls = data.properties.map(p => ({ url: p.url, id: p.id }));
                
                console.log(`✓ Loaded page 1: ${data.properties.length} properties`);
                console.log(`Total: ${data.total}, Pages: ${data.total_pages}, Has more: ${data.has_more}`);
                console.log(`Images in first property: ${data.properties[0]?.images?.length || 0}`);
                console.log(`Sold data in first property: ${data.properties[0]?.sold_properties?.length || 0}`);
                
                displayProperties(loadedProperties);
                loading.classList.remove('active');
                showAlert('success', `Loaded ${data.properties.length} of ${data.total} properties`);
                
                // If there are more pages, load them in background
                if (data.has_more) {
                    console.log(`Loading remaining ${data.total_pages - 1} pages in background...`);
                    showAlert('success', `Loading remaining pages (${data.total_pages - 1} more)... Please wait.`);
                    
                    let failedPages = [];
                    for (let page = 2; page <= data.total_pages; page++) {
                        try {
                            const pageData = await loadPropertiesPage(page);
                            if (pageData && pageData.properties && pageData.properties.length > 0) {
                                // Debug: Check sold data on this page
                                const withSold = pageData.properties.filter(p => p.sold_properties && p.sold_properties.length > 0).length;
                                console.log(`✓ Page ${page}/${data.total_pages}: ${pageData.properties.length} properties, ${withSold} with sold data`);
                                
                                loadedProperties = loadedProperties.concat(pageData.properties);
                                propertyUrls = propertyUrls.concat(pageData.properties.map(p => ({ url: p.url, id: p.id })));
                                
                                // Update loaded count progressively
                                loadedCount.textContent = loadedProperties.length;
                                
                                // Update display every 5 pages for better UX
                                if (page % 5 === 0) {
                                    displayProperties(loadedProperties);
                                }
                            } else {
                                console.warn(`Page ${page} returned no properties`);
                                failedPages.push(page);
                            }
                            
                            // Small delay between requests to avoid overwhelming the server
                            await new Promise(resolve => setTimeout(resolve, 100));
                            
                        } catch (pageError) {
                            console.error(`Error loading page ${page}:`, pageError);
                            failedPages.push(page);
                            // Continue loading other pages despite error
                        }
                    }
                    
                    // Final display with all loaded data
                    console.log(`All pages processed. Total loaded: ${loadedProperties.length} properties`);
                    displayProperties(loadedProperties);
                    
                    if (failedPages.length > 0) {
                        showAlert('error', `Loaded ${loadedProperties.length} properties. ${failedPages.length} pages failed to load.`);
                    } else {
                        showAlert('success', `All ${loadedProperties.length} properties loaded!`);
                    }
                }
                
            } catch (error) {
                console.error('=== ERROR LOADING FROM DATABASE ===');
                console.error('Error:', error);
                console.error('Stack:', error.stack);
                loading.classList.remove('active');
                emptyState.classList.add('active');
                statsBar.style.display = 'none';
            }
        }
        
        // Load a single page of properties from database - OPTIMIZED for speed
        async function loadPropertiesPage(page) {
            try {
                // Ensure search_id is explicitly handled as a string parameter if present
                // This fixes the issue where implicit object-to-string conversion might fail in some browsers
                let url = `/internal-properties/load?page=${page}&per_page=50`;
                
                if (window.searchContext && window.searchContext.id) {
                    url += `&search_id=${window.searchContext.id}`;
                }
                
                console.log(`Loading page ${page} from:`, url);
                
                const response = await fetch(url, {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (!data.success) {
                    console.error('Response not successful:', data.message);
                    return null;
                }
                
                return data;
                
            } catch (error) {
                console.error(`Error loading page ${page}:`, error);
                return null;
            }
        }

        // Import all properties using QUEUE-BASED background processing
        // This dispatches a job to the queue and polls for progress
        async function importAllProperties(isImport = true) {
            const importLoading = document.getElementById('importLoading');
            
            try {
                // Hide empty state if we are importing
                emptyState.classList.remove('active');
                
                successAlert.classList.remove('active');
                errorAlert.classList.remove('active');
                
                // Don't show loader - we'll show banner instead after job is started
                // importLoading.classList.add('active');
                syncBtn.disabled = true;

                showAlert('info', '🚀 Starting background import...');
                
                // Start the queued import
                const startResponse = await fetch('/internal-properties/import/start', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        search_id: window.searchContext ? window.searchContext.id : null,
                        url: window.searchContext ? window.searchContext.updates_url : null
                    })
                });

                if (!startResponse.ok) {
                    const errorText = await startResponse.text().catch(() => 'Unknown error');
                    let errorMessage = `Server error (${startResponse.status})`;
                    try {
                        const errorJson = JSON.parse(errorText);
                        errorMessage = errorJson.message || errorMessage;
                    } catch (e) {
                        errorMessage = errorText.substring(0, 150);
                    }
                    throw new Error(errorMessage);
                }

                const startData = await startResponse.json();
                
                if (!startData.success) {
                    throw new Error(startData.message || 'Failed to start import');
                }

                const sessionId = startData.session_id;
                console.log(`✅ Import session started: ${sessionId}`);
                
                // Hide loader - we're done with the immediate request
                document.getElementById('importLoading').classList.remove('active');
                syncBtn.disabled = false;
                
                // Show a persistent success banner with import info
                showImportStartedBanner(sessionId);

            } catch (error) {
                console.error('Error starting import:', error);
                showAlert('error', error.message || 'An error occurred while starting the import');
                emptyState.classList.add('active');
                document.getElementById('importLoading').classList.remove('active');
                syncBtn.disabled = false;
            }
        }

        // Poll for import progress until complete
        async function pollImportProgress(sessionId) {
            const pollInterval = 2000; // Poll every 2 seconds
            let lastStatus = null;
            
            const poll = async () => {
                try {
                    const response = await fetch(`/internal-properties/import/progress/${sessionId}`, {
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    
                    if (!response.ok) {
                        console.error('Progress poll failed:', response.status);
                        return;
                    }
                    
                    const data = await response.json();
                    
                    if (!data.success || !data.session) {
                        console.error('Invalid progress response:', data);
                        return;
                    }
                    
                    const session = data.session;
                    lastStatus = session.status;
                    
                    // Update progress UI
                    updateQueueProgress(session);
                    
                    // Check if finished
                    console.log(`Poll: status=${session.status}, is_finished=${session.is_finished}, total_jobs=${session.total_jobs}, completed=${session.completed_jobs}, imported=${session.imported_properties}`);
                    if (session.is_finished) {
                        console.log(`✅ Import finished with status: ${session.status}`);
                        
                        if (session.status === 'completed') {
                            // Hide loader IMMEDIATELY when complete
                            document.getElementById('importLoading').classList.remove('active');
                            syncBtn.disabled = false;
                            
                            showAlert('success', `🎉 Import complete! ${session.imported_properties} properties imported. Loading from database...`);
                            
                            // Reload properties from database immediately
                            await loadFromDatabaseOnStartup();
                        } else if (session.status === 'failed') {
                            document.getElementById('importLoading').classList.remove('active');
                            syncBtn.disabled = false;
                            showAlert('error', `❌ Import failed: ${session.error_message || 'Unknown error'}`);
                        } else if (session.status === 'cancelled') {
                            document.getElementById('importLoading').classList.remove('active');
                            syncBtn.disabled = false;
                            showAlert('warning', '⚠️ Import was cancelled.');
                        }
                        
                        return;
                    }
                    
                    // Continue polling
                    setTimeout(poll, pollInterval);
                    
                } catch (error) {
                    console.error('Error polling progress:', error);
                    // Retry after a longer delay on error
                    setTimeout(poll, pollInterval * 2);
                }
            };
            
            // Start polling
            poll();
        }

        // Update progress UI from queue session data
        // Works for both LOCAL (immediate) and SERVER (cron-based) environments
        function updateQueueProgress(session) {
            const percentage = session.progress_percentage || 0;
            const totalJobs = session.total_jobs || 0;
            const completedJobs = session.completed_jobs || 0;
            const status = session.status || 'pending';
            
            // Get UI elements
            const progressTitle = document.getElementById('progressTitle');
            const progressStats = document.getElementById('progressStats');
            const progressStatusMessage = document.getElementById('progressStatusMessage');
            const statusMessageText = document.getElementById('statusMessageText');
            
            // WAITING STATE: When jobs haven't been dispatched yet (server cron delay)
            if (status === 'pending' || (status === 'processing' && totalJobs === 0)) {
                // Show waiting message (important for cPanel where cron runs every minute)
                progressStatusMessage.style.display = 'block';
                statusMessageText.innerHTML = '⏳ <strong>Waiting for queue worker...</strong> Jobs will start processing within 1 minute (server cron). Please wait.';
                progressTitle.textContent = 'Starting Import...';
                progressStats.innerHTML = '<span style="color: #d97706;">Queued, waiting...</span>';
                
                // Show indeterminate progress
                progressBarFill.style.width = '100%';
                progressBarFill.style.background = 'linear-gradient(90deg, #fbbf24, #f59e0b, #fbbf24)';
                progressBarFill.style.animation = 'shimmer 1.5s infinite linear';
                progressPercentage.textContent = '...';
                
                // Hide speed/ETA since nothing started yet
                importSpeed.textContent = '';
                importETA.textContent = '';
                propertiesImported.textContent = '0';
                totalPropertiesEl.textContent = 'estimating...';
                
                // Update simple stats even in pending state
                const simpleLoaded = document.getElementById('simpleLoadedCount');
                const simpleTotal = document.getElementById('simpleTotalCount');
                if (simpleLoaded) simpleLoaded.textContent = session.imported_properties || 0;
                if (simpleTotal) simpleTotal.textContent = session.total_properties || '...';
                
            } else if (status === 'processing' && totalJobs > 0) {
                // PROCESSING STATE: Jobs are running
                progressStatusMessage.style.display = 'none';
                progressTitle.textContent = 'Importing Properties';
                
                // Reset progress bar to normal style
                progressBarFill.style.background = 'linear-gradient(90deg, var(--primary), var(--secondary))';
                progressBarFill.style.width = `${percentage}%`;
                progressPercentage.textContent = `${percentage}%`;
                
                // Update counters
                currentChunkEl.textContent = completedJobs;
                totalChunksEl.textContent = totalJobs;
                propertiesImported.textContent = session.imported_properties || 0;
                totalPropertiesEl.textContent = session.total_properties || '...';

                // NEW: Update simple stats
                const simpleLoaded = document.getElementById('simpleLoadedCount');
                const simpleTotal = document.getElementById('simpleTotalCount');
                if (simpleLoaded) simpleLoaded.textContent = session.imported_properties || 0;
                if (simpleTotal) simpleTotal.textContent = session.total_properties || '...';
                
                // Calculate ETA
                if (session.estimated_remaining) {
                    importETA.textContent = formatETA(session.estimated_remaining);
                } else {
                    importETA.textContent = '';
                }
                
                // Calculate speed
                if (session.elapsed_seconds && session.imported_properties) {
                    const speed = session.imported_properties / session.elapsed_seconds;
                    importSpeed.textContent = `${speed.toFixed(1)} props/sec`;
                } else {
                    importSpeed.textContent = '';
                }
                
            } else {
                // COMPLETED/FAILED STATE
                progressStatusMessage.style.display = 'none';
            }
            
            // ALWAYS update simple stats regardless of state
            const simpleLoaded = document.getElementById('simpleLoadedCount');
            const simpleTotal = document.getElementById('simpleTotalCount');
            if (simpleLoaded) simpleLoaded.textContent = session.imported_properties || 0;
            if (simpleTotal) simpleTotal.textContent = session.total_properties || '...';
            
            // Log for debugging
            console.log(`[Progress] Status: ${status}, Jobs: ${completedJobs}/${totalJobs}, Properties: ${session.imported_properties || 0}/${session.total_properties || '?'}, SimpleStats updated`);
            
            if (session.split_count) {
                console.log(`[Progress] Split info: ${session.split_count} splits, max depth ${session.max_depth_reached || 0}`);
            }
        }

        // Load property details with CONCURRENT batches (OPTIMIZED FOR SPEED)
        async function loadDetailsConcurrently(urls) {
            const batchSize = 20; // Properties per chunk
            const maxConcurrent = 6; // Chunks processed simultaneously
            let processed = 0;
            const totalBatches = Math.ceil(urls.length / batchSize);
            const startTime = Date.now();
            
            console.log(`Starting concurrent loading: ${urls.length} properties in ${totalBatches} batches, ${maxConcurrent} at a time`);
            
            // Show progress bar
            showProgressBar(urls.length, totalBatches);

            // Process batches with concurrency limit
            for (let i = 0; i < totalBatches; i += maxConcurrent) {
                const currentChunkSet = Math.floor(i / maxConcurrent) + 1;
                
                // Create array of batch promises (up to maxConcurrent)
                const batchPromises = [];
                
                for (let j = 0; j < maxConcurrent && (i + j) < totalBatches; j++) {
                    const batchIndex = i + j;
                    const startIdx = batchIndex * batchSize;
                    const endIdx = Math.min(startIdx + batchSize, urls.length);
                    const batch = urls.slice(startIdx, endIdx);
                    
                    // Create promise for this batch
                    const batchPromise = fetchBatch(batch, batchIndex + 1, totalBatches)
                        .then(result => {
                            if (result.success && result.properties) {
                                console.log(`✓ Chunk ${batchIndex + 1}/${totalBatches} completed: ${result.properties.length} properties`);
                                
                                // Debug: Check first property in batch
                                if (result.properties.length > 0) {
                                    const firstProp = result.properties[0];
                                    console.log(`Sample property from chunk ${batchIndex + 1}:`, {
                                        id: firstProp.id,
                                        images: firstProp.images?.length || 0,
                                        soldProperties: firstProp.sold_properties?.length || 0,
                                        hasImages: !!firstProp.images,
                                        hasSold: !!firstProp.sold_properties,
                                        fullProperty: firstProp
                                    });
                                }
                                
                                // Update properties with full details
                                result.properties.forEach(prop => {
                                    // Match by URL OR by property ID (more robust fallback)
                                    let index = loadedProperties.findIndex(p => p.url === prop.url);
                                    
                                    if (index === -1 && prop.id) {
                                        index = loadedProperties.findIndex(p => p.id == prop.id || (p.url && p.url.includes(prop.id)));
                                    }

                                    if (index !== -1) {
                                        // CRITICAL: Ensure images and sold_properties from backend are preserved
                                        const mergedProperty = {
                                            ...loadedProperties[index], 
                                            ...prop, 
                                            loading: false,
                                            // Explicitly ensure these arrays are set
                                            images: prop.images || [],
                                            sold_properties: prop.sold_properties || []
                                        };
                                        
                                        loadedProperties[index] = mergedProperty;
                                        
                                        // Debug: Verify merged data
                                        console.log(`Merged property ${prop.id}:`, {
                                            id: mergedProperty.id,
                                            images: mergedProperty.images?.length || 0,
                                            sold: mergedProperty.sold_properties?.length || 0,
                                            urlMatch: loadedProperties[index].url === prop.url
                                        });
                                        
                                        updatePropertyCard(mergedProperty);
                                        processed++;
                                        loadedCount.textContent = processed;
                                    } else {
                                        console.warn(`Could not find placeholder for property ${prop.id} / ${prop.url}`);
                                    }
                                });
                                
                                // Update progress after each chunk completes
                                updateProgress(processed, urls.length, startTime, batchIndex + 1, totalBatches);

                                // Re-sort current view if details arrived for properties
                                const sortSelect = document.getElementById('sortProperties');
                                if (sortSelect && sortSelect.value && sortSelect.value !== 'default') {
                                    sortProperties(sortSelect.value);
                                }
                            }
                            return result;
                        })
                        .catch(err => {
                            console.error(`Error in chunk ${batchIndex + 1}:`, err);
                            return { success: false, error: err.message };
                        });
                    
                    batchPromises.push(batchPromise);
                }
                
                // Wait for all concurrent batches to complete
                console.log(`Processing chunks ${i + 1} to ${Math.min(i + maxConcurrent, totalBatches)} concurrently...`);
                await Promise.all(batchPromises);
            }

            // Hide progress bar and import loader, show completion
            hideProgressBar();
            document.getElementById('importLoading').classList.remove('active');
            syncBtn.disabled = false;
            
            // CHANGED: Don't auto-fetch sold data, let user click the button instead
            // await autoFetchAllSoldData();
            
            // Show the Import Sold Properties button for user to click
            autoShowSoldImportBtn();
            showAlert('success', `✓ Import complete! ${processed} properties loaded. Click "Import Sold Properties" button to fetch sold data.`);
        }
        
        // Automatically fetch sold data for ALL properties that don't have it
        async function autoFetchAllSoldData() {
            console.log('🔄 Starting automatic sold data fetch for all properties...');
            
            const propsWithoutSold = loadedProperties.filter(p => 
                !p.sold_properties || p.sold_properties.length === 0
            );
            
            if (propsWithoutSold.length === 0) {
                console.log('✅ All properties already have sold data');
                showAlert('success', '✅ All properties have sold data. Ready!');
                return;
            }
            
            showAlert('success', `Fetching sold data for ${propsWithoutSold.length} properties...`);
            
            let fetched = 0;
            let totalSoldFound = 0;
            
            for (const prop of propsWithoutSold) {
                try {
                    const response = await fetch('/internal-properties/process-sold', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({ property_id: prop.id })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success && data.property) {
                        const idx = loadedProperties.findIndex(p => p.id == prop.id);
                        if (idx !== -1) {
                            loadedProperties[idx] = data.property;
                            totalSoldFound += data.property.sold_properties?.length || 0;
                        }
                    }
                } catch (err) {
                    console.error(`Error fetching sold for ${prop.id}:`, err);
                }
                
                fetched++;
                
                // Update progress every 10 properties
                if (fetched % 10 === 0) {
                    console.log(`Sold data: ${fetched}/${propsWithoutSold.length} processed`);
                }
            }
            
            // Refresh display with new sold data
            displayProperties(loadedProperties);
            
            console.log(`✅ Sold data fetch complete. Found ${totalSoldFound} sold records.`);
            showAlert('success', `✅ Complete! ${totalSoldFound} sold records loaded. Discount badges ready!`);
        }
        
        // Progress Bar Helper Functions
        function showProgressBar(total, chunks) {
            // importProgress.classList.add('active'); // Hidden as requested
            document.getElementById('importLoading').classList.add('active');
            
            totalPropertiesEl.textContent = total;
            totalChunksEl.textContent = chunks;
            currentChunkEl.textContent = '0';
            propertiesImported.textContent = '0';
            progressBarFill.style.width = '0%';
            progressPercentage.textContent = '0%';
            importSpeed.textContent = '';
            importETA.textContent = '';
            
            // Initialize simple stats
            const simpleLoaded = document.getElementById('simpleLoadedCount');
            const simpleTotal = document.getElementById('simpleTotalCount');
            if (simpleLoaded) simpleLoaded.textContent = '0';
            if (simpleTotal) simpleTotal.textContent = total;
        }
        
        function updateProgress(current, total, startTime, currentChunk, totalChunks) {
            // Update chunk counter
            currentChunkEl.textContent = currentChunk;
            
            // New simple stats
            const simpleLoaded = document.getElementById('simpleLoadedCount');
            const simpleTotal = document.getElementById('simpleTotalCount');
            if (simpleLoaded) simpleLoaded.textContent = current;
            if (simpleTotal) simpleTotal.textContent = total;
            
            // Update properties count
            propertiesImported.textContent = current;
            
            // Calculate and update percentage
            const percentage = Math.round((current / total) * 100);
            progressBarFill.style.width = `${percentage}%`;
            progressPercentage.textContent = `${percentage}%`;
            
            // Calculate speed (properties per second)
            const elapsed = (Date.now() - startTime) / 1000; // seconds
            const speed = current / elapsed;
            importSpeed.textContent = `${speed.toFixed(1)} props/sec`;
            
            // Calculate ETA
            if (current < total && speed > 0) {
                const remaining = total - current;
                const etaSeconds = remaining / speed;
                importETA.textContent = formatETA(etaSeconds);
            } else {
                importETA.textContent = '';
            }
        }
        
        function hideProgressBar() {
            setTimeout(() => {
                // importProgress.classList.remove('active');
                document.getElementById('importLoading').classList.remove('active');
            }, 3000); // Keep visible for 3 seconds after completion
        }
        
        // Show a simple banner when import is started (no polling required)
        // DISABLED: Banner hidden per user request
        function showImportStartedBanner(sessionId) {
            console.log(`DEBUG: Banner display disabled per user request (session #${sessionId})`);
            return; // Exit early - don't show banner
            
            // Create or update import banner
            let banner = document.getElementById('importStatusBanner');
            if (!banner) {
                console.log('DEBUG: Creating new banner element');
                banner = document.createElement('div');
                banner.id = 'importStatusBanner';
                banner.style.cssText = `
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    padding: 1rem 1.5rem;
                    border-radius: 12px;
                    margin-bottom: 1.5rem;
                    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
                    display: flex !important;
                    align-items: center;
                    justify-content: space-between;
                    flex-wrap: wrap;
                    gap: 1rem;
                    position: relative;
                    z-index: 9999;
                `;
                
                // Insert after header – MORE ROBUST INSERTION
                const header = document.querySelector('.header');
                if (header) {
                    header.after(banner);
                    console.log('DEBUG: Banner inserted after .header');
                } else {
                    const container = document.querySelector('.container');
                    if (container) {
                        container.prepend(banner);
                        console.log('DEBUG: Banner prepended to .container');
                    } else {
                        document.body.prepend(banner);
                        console.log('DEBUG: Banner prepended to body as fallback');
                    }
                }
            }
            
            banner.innerHTML = `
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="animation: spin 1s linear infinite;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                    </svg>
                    <div>
                        <strong>🚀 Import Running in Background</strong>
                        <div id="importStatusText" style="font-size: 0.85rem; opacity: 0.9; margin-top: 0.25rem;">
                            Session #${sessionId} • <span class="stats-loading">Fetching progress...</span>
                        </div>
                    </div>
                </div>
                <style>
                    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                </style>
            `;
            
            banner.style.display = 'flex';
            
            // Also show a simple alert
            showAlert('success', `🚀 Import started! Session #${sessionId}. Page will refresh automatically when done.`);
            
            // Start auto-refresh polling - checks every 10 seconds if import is complete
            startAutoRefreshPolling(sessionId);
        }
        
        // Poll for import completion and auto-refresh when done
        function startAutoRefreshPolling(sessionId) {
            const checkInterval = 10000; // Check every 10 seconds for better responsiveness
            
            const checkCompletion = async () => {
                try {
                    const response = await fetch('/internal-properties/import/sessions', {
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        if (data.success && data.sessions) {
                            // Find our specific session in the list
                            const session = data.sessions.find(s => s.id == sessionId);
                            
                            if (session) {
                                // Log progress for debugging
                                console.log(`Progress: ${session.imported_properties || 0}/${session.total_properties || '?'} properties, Jobs: ${session.completed_jobs}/${session.total_jobs}, Status: ${session.status}`);
                                
                                // Update banner with current progress
                                const statusText = document.getElementById('importStatusText');
                                if (statusText) {
                                    const imported = session.imported_properties !== null ? session.imported_properties : 0;
                                    const total = session.total_properties !== null ? session.total_properties : '...';
                                    const jobs = session.completed_jobs !== null ? session.completed_jobs : 0;
                                    const totalJobs = session.total_jobs !== null ? session.total_jobs : 0;
                                    
                                    const totalStr = typeof total === 'number' ? total.toLocaleString() : total;
                                    statusText.innerHTML = `Session #${sessionId} • <strong>${imported.toLocaleString()}</strong> / <strong>${totalStr}</strong> properties imported • <strong>Job ${jobs} / ${totalJobs}</strong>`;
                                }
                                
                                // Check if finished - with fallback detection
                                const allJobsDone = session.total_jobs > 0 && session.completed_jobs >= session.total_jobs;
                                const isComplete = session.is_finished || session.status === 'completed' || allJobsDone;
                                
                                if (isComplete) {
                                    console.log('✅ Import finished! Auto-refreshing...');
                                    // Remove the banner immediately
                                    const banner = document.getElementById('importStatusBanner');
                                    if (banner) banner.remove();
                                    
                                    if (session.status === 'completed' || allJobsDone) {
                                        showAlert('success', `🎉 Import complete! ${session.imported_properties || 0} properties imported. Loading from database...`);
                                    } else if (session.status === 'failed') {
                                        showAlert('error', `❌ Import failed: ${session.error_message || 'Unknown error'}`);
                                    }
                                    setTimeout(() => location.reload(), 2000);
                                    return; // Stop polling
                                }
                            } else {
                                console.log(`Session #${sessionId} not found in recent sessions.`);
                            }
                        }
                    } else {
                        console.log(`Progress update failed: Server returned ${response.status}`);
                    }
                    
                    // Continue polling
                    setTimeout(checkCompletion, checkInterval);
                    
                } catch (error) {
                    console.log('Progress check failed, retrying...', error);
                    setTimeout(checkCompletion, checkInterval);
                }
            };
            
            // Start first check IMMEDIATELY, then every 10 seconds
            checkCompletion();
        }
        
        function formatETA(seconds) {
            if (seconds < 60) {
                return `~${Math.ceil(seconds)}s remaining`;
            } else if (seconds < 3600) {
                const minutes = Math.ceil(seconds / 60);
                return `~${minutes}m remaining`;
            } else {
                const hours = Math.floor(seconds / 3600);
                const minutes = Math.ceil((seconds % 3600) / 60);
                return `~${hours}h ${minutes}m remaining`;
            }
        }

        // Fetch a single batch of properties
        async function fetchBatch(batch, batchNum, totalBatches) {
            console.log(`Fetching batch ${batchNum}/${totalBatches} (${batch.length} properties)`);
            
            try {
                const response = await fetch('/internal-properties/fetch-all', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ 
                        urls: batch,
                        filter_id: window.searchContext ? window.searchContext.id : null,
                        skip_sold: true // SPEED OPTIMIZATION: Skip intensive sold-scraping for mass imports
                    })
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();
                console.log(`Batch ${batchNum}/${totalBatches} completed:`, data.processed, 'properties');
                
                return data;
                
            } catch (error) {
                console.error(`Batch ${batchNum} error:`, error);
                throw error;
            }
        }

        // Update a single property card with new data
        function updatePropertyCard(property) {
            // Debug: Log what data we're receiving
            console.log(`Updating card for property ${property.id}:`, {
                hasImages: property.images && property.images.length > 0,
                imageCount: property.images?.length || 0,
                hasSoldData: property.sold_properties && property.sold_properties.length > 0,
                soldCount: property.sold_properties?.length || 0,
                loading: property.loading,
                fullProperty: property
            });
            
            // IMPORTANT: Ensure we have the full property data with images and sold_properties
            // The backend sends this data, but we need to make sure it's merged properly
            if (!property.images) {
                console.warn(`Property ${property.id} has no images array`);
                property.images = [];
            }
            if (!property.sold_properties) {
                console.warn(`Property ${property.id} has no sold_properties array`);
                property.sold_properties = [];
            }
            
            let card = document.getElementById(`card-${property.id}`);
            
            // Fallback: search by URL if ID lookup fails (common during initial import)
            if (!card) {
                const urlLink = document.querySelector(`a[href="${property.url}"]`);
                if (urlLink) {
                    card = urlLink.closest('.property-card');
                    if (card) {
                        console.log(`✓ Card found via URL for property ${property.id}`);
                    }
                }
            }
            
            if (card) {
                // Create new card HTML with full data
                const newCardHTML = createPropertyCard(property, 0);
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = newCardHTML;
                const newCard = tempDiv.firstElementChild;
                
                // Replace the card
                card.parentNode.replaceChild(newCard, card);
                
                // Log successful update
                console.log(`✓ Card updated for property ${property.id} with ${property.images.length} images and ${property.sold_properties.length} sold properties`);
            } else {
                console.warn(`Card not found for property ${property.id} (tried ID and URL search)`);
            }
        }

        // Display properties in grid with pagination
        function displayProperties(props) {
            // DEBUG: Analyze discount metric distribution (with inverted metric)
            const discountProps = props.filter(p => p.discount_metric !== null && p.discount_metric !== undefined && parseFloat(p.discount_metric) >= 0);
            const premiumProps = props.filter(p => p.discount_metric !== null && p.discount_metric !== undefined && parseFloat(p.discount_metric) < 0);
            const noDataProps = props.filter(p => p.discount_metric === null || p.discount_metric === undefined);
            
            console.log('📊 DISCOUNT METRIC ANALYSIS (Inverted: Positive=Discount, Negative=Premium):');
            console.log(`   🟢 Properties with DISCOUNT (green badge, positive): ${discountProps.length}`);
            console.log(`   🔴 Properties with PREMIUM (red badge, negative): ${premiumProps.length}`);
            console.log(`   ⚪ Properties with NO DATA: ${noDataProps.length}`);
            
            if (discountProps.length > 0) {
                console.log('   🟢 Sample discounts:', discountProps.slice(0, 3).map(p => ({addr: p.address, metric: p.discount_metric})));
            }
            if (premiumProps.length > 0) {
                console.log('   🔴 Sample premiums:', premiumProps.slice(0, 3).map(p => ({addr: p.address, metric: p.discount_metric})));
            }
            
            // Calculate slice for current page
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const pageProps = props.slice(startIndex, endIndex);

            // Render current page items
            propertiesGrid.innerHTML = pageProps.map((property, index) => {
                currentImageIndexes[property.id] = 0;
                return createPropertyCard(property, index);
            }).join('');

            // Render pagination controls
            renderPagination(props.length);

            // Add event listeners for image navigation
            pageProps.forEach(property => {
                const prevBtn = document.getElementById(`prev-${property.id}`);
                const nextBtn = document.getElementById(`next-${property.id}`);

                if (prevBtn) {
                    prevBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        navigateImage(property.id, -1, property.images.length);
                    });
                }

                if (nextBtn) {
                    nextBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        navigateImage(property.id, 1, property.images.length);
                    });
                }

                // Card click to view original listing
                const card = document.getElementById(`card-${property.id}`);
                if (card) {
                    card.addEventListener('click', () => {
                        window.open(property.url || property.original_data?.url, '_blank');
                    });
                }
            });

            // Update header import sold button visibility
            autoShowSoldImportBtn();
        }

        // Toggle visibility of global "Import Sold Properties" button
        function autoShowSoldImportBtn() {
            const btn = document.getElementById('headerImportSoldBtn');
            if (!btn || !loadedProperties) return;

            const propsWithoutSold = loadedProperties.filter(p => !p.sold_properties || p.sold_properties.length === 0);
            
            if (propsWithoutSold.length > 0) {
                btn.style.display = 'flex';
                btn.innerHTML = `
                    <svg class="sync-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Import Sold Properties (${propsWithoutSold.length})
                `;
            } else {
                btn.style.display = 'none';
            }
        }

        // Bulk import sold data for properties missing it - QUEUE-BASED (fast!)
        async function fetchRemainingSoldData() {
            const btn = document.getElementById('headerImportSoldBtn');
            if (!btn || btn.disabled) return;

            const propsWithoutSold = loadedProperties.filter(p => !p.sold_properties || p.sold_properties.length === 0);
            
            if (propsWithoutSold.length === 0) {
                showAlert('success', 'All properties already have sold data!');
                return;
            }

            btn.disabled = true;
            const originalContent = btn.innerHTML;
            
            try {
                btn.innerHTML = `
                    <span class="spinner-sm" style="display:inline-block; width:12px; height:12px; border:2px solid currentColor; border-top-color:transparent; border-radius:50%; animation:spin 1s linear infinite;"></span>
                    Dispatching ${propsWithoutSold.length} jobs...
                `;
                
                // Get all property IDs that need sold data
                const propertyIds = propsWithoutSold.map(p => p.id);
                
                // Send ALL property IDs to the queue endpoint at once
                const response = await fetch('/internal-properties/import/sold', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ property_ids: propertyIds })
                });

                const data = await response.json();
                
                if (data.success) {
                    const jobCount = data.jobs_dispatched || 0;
                    
                    showAlert('success', `✅ Dispatched ${jobCount} sold import jobs! Monitoring progress...`);
                    
                    // Start polling for completion
                    btn.innerHTML = `
                        <span class="spinner-sm" style="display:inline-block; width:12px; height:12px; border:2px solid currentColor; border-top-color:transparent; border-radius:50%; animation:spin 1s linear infinite;"></span>
                        Processing ${jobCount} jobs...
                    `;
                    
                    // Poll for completion every 5 seconds
                    const pollForCompletion = async () => {
                        try {
                            // Check how many properties now have sold data
                            const checkResponse = await fetch(
                                window.searchContext 
                                    ? `/internal-properties/load?search_id=${window.searchContext.id}&page=1&per_page=1`
                                    : `/internal-properties/load?page=1&per_page=1`,
                                {
                                    method: 'GET',
                                    headers: {
                                        'Accept': 'application/json',
                                        'X-Requested-With': 'XMLHttpRequest'
                                    }
                                }
                            );
                            
                            // Simple check: reload after a reasonable time based on job count
                            // Each job takes ~2-5 seconds on average
                            const estimatedTime = Math.min(jobCount * 3, 180); // Max 3 minutes
                            const elapsedTime = (Date.now() - pollStartTime) / 1000;
                            const remainingTime = Math.max(0, estimatedTime - elapsedTime);
                            
                            if (remainingTime > 0) {
                                btn.innerHTML = `
                                    <span style="color: #10b981;">⏳</span>
                                    ~${Math.ceil(remainingTime)}s remaining...
                                `;
                                setTimeout(pollForCompletion, 5000);
                            } else {
                                // Time's up - refresh the page
                                btn.innerHTML = `
                                    <span class="spinner-sm" style="display:inline-block; width:12px; height:12px; border:2px solid currentColor; border-top-color:transparent; border-radius:50%; animation:spin 1s linear infinite;"></span>
                                    Reloading...
                                `;
                                showAlert('success', '🎉 Sold import complete! Reloading page with all data...');
                                setTimeout(() => window.location.reload(), 1500);
                            }
                        } catch (error) {
                            console.error('Poll error:', error);
                            // On error, continue polling
                            setTimeout(pollForCompletion, 5000);
                        }
                    };
                    
                    const pollStartTime = Date.now();
                    setTimeout(pollForCompletion, 5000);
                    
                } else {
                    throw new Error(data.message || 'Failed to start sold import');
                }

            } catch (error) {
                console.error('Bulk import error:', error);
                showAlert('error', 'An error occurred during bulk import: ' + error.message);
                btn.innerHTML = originalContent;
                btn.disabled = false;
            }
        }
        
        // Import sold data for a SINGLE property (from card button)
        async function importAllSoldHistory(event, propertyId) {
            event.stopPropagation(); // Prevent card click
            
            const btn = document.getElementById(`header-import-${propertyId}`);
            if (!btn || btn.disabled) return;
            
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            
            // Show spinner
            btn.innerHTML = `
                <span class="spinner-sm active"></span>
                <span class="btn-text">Importing...</span>
            `;
            
            try {
                const response = await fetch('/internal-properties/process-sold', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ property_id: propertyId })
                });
                
                const data = await response.json();
                
                if (data.success && data.property) {
                    // Update property in array
                    const idx = loadedProperties.findIndex(p => p.id == propertyId);
                    if (idx !== -1) {
                        loadedProperties[idx] = data.property;
                        updatePropertyCard(data.property);
                    }
                    
                    showAlert('success', `Imported ${data.property.sold_properties?.length || 0} sold records`);
                    
                    // Hide button after successful import
                    btn.style.display = 'none';
                } else {
                    showAlert('error', data.message || 'Failed to import sold data');
                    btn.disabled = false;
                    btn.innerHTML = originalHTML;
                }
            } catch (error) {
                console.error('Import error:', error);
                showAlert('error', 'Error importing sold data: ' + error.message);
                btn.disabled = false;
                btn.innerHTML = originalHTML;
            }
        }

        // Render pagination controls
        function renderPagination(totalItems) {
            const totalPages = Math.ceil(totalItems / itemsPerPage);
            if (totalPages <= 1) {
                // Remove pagination if exists
                const existingNav = document.getElementById('paginationNav');
                if (existingNav) existingNav.remove();
                return;
            }

            let paginationNav = document.getElementById('paginationNav');
            if (!paginationNav) {
                paginationNav = document.createElement('div');
                paginationNav.id = 'paginationNav';
                paginationNav.className = 'pagination-nav';
                // Insert after properties grid
                propertiesGrid.parentNode.insertBefore(paginationNav, propertiesGrid.nextSibling);

                // Add pagination styles if not present
                if (!document.getElementById('paginationStyles')) {
                    const style = document.createElement('style');
                    style.id = 'paginationStyles';
                    style.textContent = `
                        .pagination-nav {
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            gap: 1rem;
                            margin: 2rem 0;
                            padding: 1rem;
                            background: var(--card-bg);
                            border-radius: 8px;
                            box-shadow: var(--shadow-sm);
                        }
                        .page-btn {
                            padding: 0.5rem 1rem;
                            border: 1px solid var(--card-border);
                            background: white;
                            border-radius: 4px;
                            cursor: pointer;
                            font-weight: 500;
                            transition: all 0.2s;
                        }
                        .page-btn:hover:not(:disabled) {
                            background: var(--primary-light);
                            border-color: var(--primary);
                            color: var(--primary);
                        }
                        .page-btn:disabled {
                            opacity: 0.5;
                            cursor: not-allowed;
                        }
                        .page-info {
                            font-size: 0.9rem;
                            color: var(--text-secondary);
                            font-weight: 500;
                        }
                        .page-controls {
                            display: flex;
                            align-items: center;
                            gap: 1rem;
                        }
                        .goto-page {
                            display: flex;
                            align-items: center;
                            gap: 0.5rem;
                        }
                        .goto-input {
                            width: 60px;
                            padding: 0.4rem;
                            border: 1px solid var(--card-border);
                            border-radius: 4px;
                            text-align: center;
                        }
                        .page-btn.small {
                            padding: 0.4rem 0.8rem;
                            font-size: 0.8rem;
                        }
                    `;
                    document.head.appendChild(style);
                }
            }

            paginationNav.innerHTML = `
                <button class="page-btn" onclick="changePage(-1)" ${currentPage === 1 ? 'disabled' : ''}>Previous</button>
                <div class="page-controls">
                    <span class="page-info">Page ${currentPage} of ${totalPages}</span>
                    <div class="goto-page">
                        <input type="number" min="1" max="${totalPages}" value="${currentPage}" 
                               class="goto-input" onchange="goToPage(this.value)" 
                               onkeydown="if(event.key === 'Enter') goToPage(this.value)">
                        <button class="page-btn small" onclick="goToPage(this.previousElementSibling.value)">Go</button>
                    </div>
                </div>
                <button class="page-btn" onclick="changePage(1)" ${currentPage === totalPages ? 'disabled' : ''}>Next</button>
            `;
        }

        // Helper to handle sold property image errors
        function handleSoldImageError(img) {
            const mapUrl = img.getAttribute('data-map');
            if (mapUrl && !img.dataset.triedMap) {
                img.dataset.triedMap = "true";
                img.src = mapUrl;
                console.log("Image failed, switching to map:", mapUrl);
            } else {
                img.src = 'https://via.placeholder.com/260x180/eee/999?text=No+Photo';
                img.onerror = null; // Prevent infinite loop
            }
        }

        // Go to specific page
        function goToPage(page) {
            page = parseInt(page);
            const totalPages = Math.ceil(loadedProperties.length / itemsPerPage);
            
            if (page >= 1 && page <= totalPages) {
                currentPage = page;
                displayProperties(loadedProperties);
                document.getElementById('header')?.scrollIntoView({ behavior: 'smooth' });
            } else {
                // Reset input to current page if invalid
                const input = document.querySelector('.goto-input');
                if (input) input.value = currentPage;
                showAlert('error', `Please enter a page between 1 and ${totalPages}`);
            }
        }

        // Change page
        function changePage(direction) {
            const totalPages = Math.ceil(loadedProperties.length / itemsPerPage);
            const newPage = currentPage + direction;

            if (newPage >= 1 && newPage <= totalPages) {
                currentPage = newPage;
                displayProperties(loadedProperties);
                document.getElementById('header')?.scrollIntoView({ behavior: 'smooth' });
            }
        }

        // Smart Deep Search Trigger
        // Automatically checks a list of properties for missing sold data and triggers import
        async function checkAndTriggerDeepSearch(properties) {
            console.log('🔍 Checking for missing sold data in ' + properties.length + ' properties...');
            
            const missingDataProps = properties.filter(p => 
                (!p.sold_properties || p.sold_properties.length === 0) &&
                !p.deep_search_attempted // custom flag to prevent infinite loops
            );
            
            if (missingDataProps.length > 0) {
                console.log(`found ${missingDataProps.length} properties with missing sold data. Initiating Deep Search...`);
                showAlert('success', `Found ${missingDataProps.length} properties missing sold data. Deep searching source...`);
                
                // Process one by one to avoid overwhelming server
                for (const prop of missingDataProps) {
                    // Mark as attempted so we don't try again repeatedly
                    prop.deep_search_attempted = true;
                    
                    // Trigger import
                    await importAllSoldHistory(new Event('submit'), prop.id, true); // true = silent/background mode
                    
                    // Small delay
                    await new Promise(r => setTimeout(r, 1000));
                }
            }
        }

        // Create property card HTML - matches screenshot design exactly
        // Sorting Handlers
        function handleSortChange() {
            const sortType = document.getElementById('sortSelect').value;
            sortProperties(sortType);
        }

        function sortProperties(type) {
            // Sort the loadedProperties array DIRECTLY so pagination uses sorted order
            
            switch(type) {
                case 'price_low':
                    loadedProperties.sort((a, b) => parseNumericPrice(a.price) - parseNumericPrice(b.price));
                    break;
                case 'price_high':
                    loadedProperties.sort((a, b) => parseNumericPrice(b.price) - parseNumericPrice(a.price));
                    break;
                case 'avg_price_low':
                    loadedProperties.sort((a, b) => (parseFloat(a.average_sold_price) || 0) - (parseFloat(b.average_sold_price) || 0));
                    break;
                case 'avg_price_high':
                    loadedProperties.sort((a, b) => (parseFloat(b.average_sold_price) || 0) - (parseFloat(a.average_sold_price) || 0));
                    break;
                case 'discount_high':
                    // MATHEMATICAL DESCENDING: +50%, +10%, 0%, -1%, -10%, -50%
                    // This puts Discounts (Green) first by magnitude, then Premiums (Red) by lowest magnitude first.
                    loadedProperties.sort((a, b) => {
                        const vA = (a.discount_metric !== null && a.discount_metric !== undefined && !isNaN(parseFloat(a.discount_metric))) 
                            ? parseFloat(a.discount_metric) : -1e12;
                        const vB = (b.discount_metric !== null && b.discount_metric !== undefined && !isNaN(parseFloat(b.discount_metric))) 
                            ? parseFloat(b.discount_metric) : -1e12;
                        return vB - vA;
                    });
                    
                    console.log('--- SORT DEBUG: Largest Discount ---');
                    console.log('Total items:', loadedProperties.length);
                    loadedProperties.slice(0, 5).forEach((p, i) => console.log(`${i+1}. ${p.address?.substring(0, 30)}: ${p.discount_metric}%`));
                    break;
                    
                case 'discount_low':
                    // SMALLEST DISCOUNT / LARGEST PREMIUM FIRST (with inverted metric):
                    // Negative values = Premium (RED) - show these first (-30%, -20%)
                    // Then positive values = Discount (GREEN) - (+5%, +10%, +30%)
                    // Sort ASCENDING: -30 < -10 < +5 < +20 < null
                    loadedProperties.sort((a, b) => {
                        const valA = (a.discount_metric !== null && a.discount_metric !== undefined && !isNaN(parseFloat(a.discount_metric))) 
                            ? parseFloat(a.discount_metric) : 999999;
                        const valB = (b.discount_metric !== null && b.discount_metric !== undefined && !isNaN(parseFloat(b.discount_metric))) 
                            ? parseFloat(b.discount_metric) : 999999;
                        return valA - valB; // Ascending: most premium (negative) first
                    });
                    break;
                    
                case 'road_asc':
                    loadedProperties.sort((a, b) => {
                        const roadA = (a.road_name || a.address || '').toLowerCase();
                        const roadB = (b.road_name || b.address || '').toLowerCase();
                        return roadA.localeCompare(roadB);
                    });
                    break;
                default:
                    // Default order (usually chronological or by ID)
                    break;
            }
            
            currentPage = 1;
            displayProperties(loadedProperties);
        }

        function parseNumericPrice(priceStr) {
            if (!priceStr) return 0;
            if (typeof priceStr === 'number') return priceStr;
            const numeric = parseFloat(priceStr.replace(/[£,]/g, ''));
            return isNaN(numeric) ? 0 : numeric;
        }

        function createPropertyCard(property, index) {
            const hasImages = property.images && property.images.length > 0;
            const imageCount = hasImages ? property.images.length : 0;
            const loadingClass = property.loading ? 'loading' : '';
            
            // Use first image or placeholder
            const mainImage = hasImages ? property.images[0] : `https://via.placeholder.com/600x400/e0e0e0/666666?text=Loading+Image`;

            // Format address with house number if possible
            const houseNumber = property.house_number || '';
            const roadName = property.road_name || property.address || '';
            const displayAddress = houseNumber ? `<span class="address-house">${houseNumber},</span> <span class="address-road">${roadName}</span>` : roadName;

            // Create property card HTML - Split Layout
            return `
                <div class="property-card ${loadingClass}" id="card-${property.id}" style="animation-delay: ${index * 0.01}s;">
                    <!-- LEFT SIDE: Property Details -->
                    <div class="property-main-content">
                        <div class="property-image-section">
                            <div class="image-slider-wrapper">
                                <div class="image-slides" id="slides-${property.id}">
                                    ${hasImages ? 
                                        property.images.map((img, idx) => `
                                            <div class="image-slide ${idx === 0 ? 'active' : ''}">
                                                <img src="${img}" alt="Property image" loading="lazy" onerror="this.src='https://via.placeholder.com/600x400/e0e0e0/666666?text=Image+Not+Found'">
                                            </div>
                                        `).join('') : 
                                        `<div class="image-slide active">
                                            <img src="${mainImage}" alt="Loading...">
                                        </div>`
                                    }
                                </div>
                                ${hasImages && imageCount > 1 ? `
                                    <button class="nav-arrow left" onclick="event.stopPropagation(); navigateSlide('${property.id}', -1, ${imageCount})">‹</button>
                                    <button class="nav-arrow right" onclick="event.stopPropagation(); navigateSlide('${property.id}', 1, ${imageCount})">›</button>
                                ` : ''}
                            </div>
                        </div>
                        
                        <div class="property-info-section">
                            ${property.discount_metric !== null && property.discount_metric !== undefined && !isNaN(parseFloat(property.discount_metric)) ? `
                                <div class="discount-badge" style="background-color: ${parseFloat(property.discount_metric) >= 0 ? '#10b981' : '#ef4444'}; color: white;">
                                    ${Math.abs(Math.round(property.discount_metric))}% ${parseFloat(property.discount_metric) >= 0 ? 'Discount' : 'Premium'}
                                </div>
                            ` : ''}
                            
                            <h3 class="property-address-title">${displayAddress}</h3>
                            <div class="property-url-wrapper" onclick="event.stopPropagation()">
                                <div class="property-url-display" id="url-display-${property.id}">
                                    <div class="property-url" title="${property.url}">
                                        <a href="${property.url}" target="_blank" id="url-link-${property.id}">${property.url}</a>
                                    </div>
                                    <button class="url-edit-btn" onclick="toggleUrlEdit('${property.id}', '${property.url.replace(/'/g, "\\'")}')"
                                            title="Edit URL">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="property-url-edit" id="url-edit-${property.id}">
                                    <input type="text" id="url-input-${property.id}" value="${property.url}" placeholder="Enter URL">
                                    <div class="url-edit-actions">
                                        <button class="url-save-btn" onclick="saveUrl('${property.id}')">Save</button>
                                        <button class="url-cancel-btn" onclick="cancelUrlEdit('${property.id}')">Cancel</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="property-price-section">
                                <span class="price-amount">${property.price}</span>
                                ${property.reduced_on ? `<span class="info-icon" title="Price information">ⓘ</span>` : ''}
                            </div>
                            
                            ${(() => {
                                if (property.average_sold_price && property.average_sold_price > 0) {
                                    const formattedAvg = '£' + Math.round(property.average_sold_price).toLocaleString('en-GB');
                                    const count = property.sales_count_in_period || 0;
                                    return `
                                        <div style="background: linear-gradient(135deg, #f0f9ff, #e0f2fe); padding: 10px 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid #0ea5e9;">
                                            <div style="font-size: 0.75rem; color: #0369a1; font-weight: 600; margin-bottom: 4px;">AVG SOLD PRICE</div>
                                            <div style="font-size: 1.25rem; font-weight: 700; color: #0c4a6e;">${formattedAvg}</div>
                                            <div style="font-size: 0.7rem; color: #64748b;">(${count} sale${count !== 1 ? 's' : ''} in period)</div>
                                        </div>
                                    `;
                                }
                                return '';
                            })()}
                            
                            ${property.reduced_on ? `
                                <div class="reduced-date">Reduced on ${property.reduced_on}</div>
                            ` : ''}
                            
                            <div class="property-details-grid">
                                <div class="detail-item">
                                    <div class="detail-label">PROPERTY TYPE</div>
                                    <div class="detail-value">
                                        <span>${property.property_type || '-'}</span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">BEDROOMS</div>
                                    <div class="detail-value">
                                        <span>${property.bedrooms || '-'}</span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">BATHROOMS</div>
                                    <div class="detail-value">
                                        <span>${property.bathrooms || '-'}</span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">SIZE</div>
                                    <div class="detail-value">
                                        <span>${property.size || 'Ask agent'}</span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">TENURE</div>
                                    <div class="detail-value">
                                        <span>${property.tenure || 'Freehold'}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <a href="${property.url}" target="_blank" class="view-btn" onclick="event.stopPropagation()">
                                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                                </svg>
                                View on Rightmove
                            </a>
                        </div>
                    </div>

                    <!-- RIGHT SIDE: Sold History Sidebar -->
                    <div class="property-sold-sidebar">
                        <div class="sold-sidebar-header">
                            <div class="sold-sidebar-left">
                                ${property.sold_link ? `
                                    <a href="${property.sold_link}" target="_blank" class="sold-sidebar-title-link" onclick="event.stopPropagation()">
                                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                        </svg>
                                        Sold History (${property.sold_properties ? property.sold_properties.length : 0})
                                    </a>
                                ` : `
                                    <div class="sold-sidebar-title">
                                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                        </svg>
                                        Sold History (${property.sold_properties ? property.sold_properties.length : 0})
                                    </div>
                                `}
                            </div>
                            
                            ${(property.sold_link || (!property.sold_properties || property.sold_properties.length === 0)) ? `
                                <button class="sold-header-import-btn" id="header-import-${property.id}" 
                                        onclick="importAllSoldHistory(event, '${property.id}')" title="Import Sold History">
                                    <span class="spinner-sm"></span>
                                    <span class="btn-text">Import</span>
                                </button>
                            ` : ''}
                        </div>
                        
                        <div class="sold-list-container">
                            ${property.sold_properties && property.sold_properties.length > 0 ? 
                                property.sold_properties.map(sold => {
                                    const soldLink = sold.detail_url || property.sold_link || '#';
                                    const soldHouse = sold.house_number || '';
                                    const soldRoad = sold.road_name || sold.location || '';
                                    
                                    const priceHtml = Array.isArray(sold.prices) ? 
                                        sold.prices.map(p => {
                                            if (!p.sold_price) return '';
                                            const raw = p.sold_price.toString().replace(/[^0-9.]/g, '');
                                            if (raw === '' || isNaN(parseFloat(raw))) {
                                                return `<div class="sold-tx-row"><span class="sold-tx-date">${p.sold_date || '-'}</span><span class="sold-tx-price">${p.sold_price}</span></div>`;
                                            }
                                            const cleanPrice = parseFloat(raw);
                                            const fmtPrice = '£' + Math.round(cleanPrice).toLocaleString('en-GB');
                                            
                                            return `
                                                <div class="sold-tx-row">
                                                    <span class="sold-tx-date">${p.sold_date || '-'}</span>
                                                    <span class="sold-tx-price">${fmtPrice}</span>
                                                </div>
                                            `;
                                        }).join('') : '';
                                    
                                    // Robust check for placeholder images to trigger map fallback
                                    const imgUrl = (sold.image_url || '').toString().toLowerCase();
                                    const isPlaceholder = !imgUrl || 
                                                         imgUrl.includes('placeholder') || 
                                                         imgUrl.includes('no-photo') ||
                                                         imgUrl.includes('no_photo') ||
                                                         imgUrl.includes('noimage') ||
                                                         imgUrl.includes('notavailable') ||
                                                         imgUrl.includes('loading') ||
                                                         imgUrl.includes('no_image') || 
                                                         imgUrl.includes('empty') ||
                                                         imgUrl.includes('media-not-available') || // Added common variant
                                                         imgUrl.includes('rightmove.co.uk/no-photo') || // Specific Rightmove variant
                                                         imgUrl.length < 15;
                                                         
                                    // Use map automatically if detected placeholder, fallback to placeholder if no map
                                    const soldPhoto = (isPlaceholder && sold.map_url) ? sold.map_url : (sold.image_url || sold.map_url || 'https://via.placeholder.com/260x180/eee/999?text=No+Photo');
                                    
                                    if (isPlaceholder && sold.map_url) {
                                        console.log(`Map forced for ${soldHouse} ${soldRoad} (Detected placeholder: ${imgUrl})`);
                                    }
                                    
                                    return `
                                    <a href="${soldLink}" target="_blank" class="sold-item-card-link" onclick="event.stopPropagation()">
                                        <div class="sold-item-card">
                                            <div class="sold-property-photo">
                                                <img src="${soldPhoto}" 
                                                     alt="Property" 
                                                     loading="lazy" 
                                                     class="sold-img"
                                                     data-map="${sold.map_url || ''}"
                                                     onerror="handleSoldImageError(this)">
                  
                                                     </div>
                                            <div class="sold-property-main">
                                                <div class="sold-property-type">
                                                    ${sold.property_type || 'Property'} (${sold.tenure || 'Unknown'})
                                                </div>
                                                <div class="sold-property-location" title="${soldHouse ? soldHouse + ', ' : ''}${soldRoad}">
                                                    ${soldHouse ? soldHouse + ', ' : ''}${soldRoad}
                                                </div>
                                                <div class="sold-beds-baths">
                                                    ${sold.bedrooms ? `<span class="sold-bed-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v11a2 2 0 002 2h14a2 2 0 002-2V7"/><path d="M21 7V5a2 2 0 00-2-2H5a2 2 0 00-2 2v2"/><path d="M3 11h18"/></svg> ${sold.bedrooms}</span>` : ''}
                                                    ${sold.bathrooms ? `<span class="sold-bath-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12h16a1 1 0 011 1v3a4 4 0 01-4 4H7a4 4 0 01-4-4v-3a1 1 0 011-1z"/><path d="M6 12V5a2 2 0 012-2h3v2.25"/></svg> ${sold.bathrooms}</span>` : ''}
                                                </div>
                                                <div class="sold-property-transactions">
                                                    ${priceHtml ? priceHtml : `<div style="font-size:0.8rem; color:var(--text-secondary);">No price data</div>`}
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    `;
                                }).join('') 
                            :   `<div style="color:var(--text-secondary); text-align:center; padding:2rem; font-style:italic;">
                                    No sold history available
                                </div>`
                            }
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Navigate image slides
        function navigateSlide(propertyId, direction, totalImages) {
            const slidesContainer = document.getElementById(`slides-${propertyId}`);
            if (!slidesContainer) return;
            
            const slides = slidesContainer.querySelectorAll('.image-slide');
            let currentIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));
            
            slides[currentIndex].classList.remove('active');
            
            currentIndex = (currentIndex + direction + totalImages) % totalImages;
            slides[currentIndex].classList.add('active');
        }
        
        // Share property
        function shareProperty(url) {
            if (navigator.share) {
                navigator.share({ url: url });
            } else {
                navigator.clipboard.writeText(url);
                alert('Link copied to clipboard!');
            }
        }
        
        // Toggle favorite
        function toggleFavorite(propertyId) {
            const btn = event.currentTarget;
            btn.classList.toggle('active');
        }

        // Navigate images
        function navigateImage(propertyId, direction, totalImages) {
            const currentIndex = currentImageIndexes[propertyId];
            let newIndex = currentIndex + direction;

            if (newIndex < 0) newIndex = totalImages - 1;
            if (newIndex >= totalImages) newIndex = 0;

            currentImageIndexes[propertyId] = newIndex;

            const slider = document.getElementById(`slider-${propertyId}`);
            const counter = document.getElementById(`counter-${propertyId}`);

            if (slider) {
                slider.style.transform = `translateX(-${newIndex * 100}%)`;
            }

            if (counter) {
                counter.textContent = `${newIndex + 1} / ${totalImages}`;
            }
        }

        // Toggle URL edit mode
        function toggleUrlEdit(propertyId, currentUrl) {
            const urlDisplay = document.getElementById(`url-display-${propertyId}`);
            const urlEdit = document.getElementById(`url-edit-${propertyId}`);
            const urlInput = document.getElementById(`url-input-${propertyId}`);
            
            if (urlDisplay && urlEdit) {
                urlDisplay.style.display = 'none';
                urlEdit.classList.add('active');
                urlInput.value = currentUrl;
                urlInput.focus();
                urlInput.select();
            }
        }
        
        // Save URL
        function saveUrl(propertyId) {
            const urlDisplay = document.getElementById(`url-display-${propertyId}`);
            const urlEdit = document.getElementById(`url-edit-${propertyId}`);
            const urlInput = document.getElementById(`url-input-${propertyId}`);
            const urlLink = document.getElementById(`url-link-${propertyId}`);
            
            const newUrl = urlInput.value.trim();
            
            if (newUrl && urlLink) {
                // Update the displayed URL
                urlLink.href = newUrl;
                urlLink.textContent = newUrl;
                urlLink.parentElement.title = newUrl;
                
                // Update the edit button's onclick with new URL
                const editBtn = urlDisplay.querySelector('.url-edit-btn');
                if (editBtn) {
                    editBtn.onclick = function() { toggleUrlEdit(propertyId, newUrl.replace(/'/g, "\\'")); };
                }
                
                // Also update the View on Rightmove button
                const card = document.getElementById(`card-${propertyId}`);
                if (card) {
                    const viewBtn = card.querySelector('.view-btn');
                    if (viewBtn) {
                        viewBtn.href = newUrl;
                    }
                }
                
                // Update the property in loadedProperties array
                const property = loadedProperties.find(p => p.id == propertyId);
                if (property) {
                    property.url = newUrl;
                }
                
                showAlert('success', 'URL updated successfully');
            }
            
            // Hide edit mode, show display mode
            urlEdit.classList.remove('active');
            urlDisplay.style.display = 'flex';
        }
        
        // Cancel URL edit
        function cancelUrlEdit(propertyId) {
            const urlDisplay = document.getElementById(`url-display-${propertyId}`);
            const urlEdit = document.getElementById(`url-edit-${propertyId}`);
            
            urlEdit.classList.remove('active');
            urlDisplay.style.display = 'flex';
        }

        // Import sold data in background after main property import
        async function importSoldDataInBackground() {
            try {
                console.log('🔄 importSoldDataInBackground: Starting...');
                showAlert('success', 'Loading sold property data in background...');
                
                console.log('🔄 Calling /internal-properties/process-sold...');
                
                // Call the existing processSoldLinks endpoint
                const response = await fetch('/internal-properties/process-sold', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });
                
                console.log('📡 Response received:', response.status, response.statusText);
                
                // Get response text first to see what we got
                const responseText = await response.text();
                console.log('📄 Response text (first 500 chars):', responseText.substring(0, 500));
                
                if (!response.ok) {
                    console.error('❌ HTTP Error:', response.status, responseText);
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                // Try to parse as JSON
                let data;
                try {
                    data = JSON.parse(responseText);
                    console.log('📦 Response data:', data);
                } catch (parseError) {
                    console.error('❌ Failed to parse JSON:', parseError);
                    console.error('Response was:', responseText);
                    throw new Error('Server returned invalid JSON (probably an error page)');
                }
                
                if (data.success) {
                    console.log(`✅ Sold data import complete: ${data.sold_properties} sold properties with ${data.sold_prices} price records`);
                    showAlert('success', `Sold data loaded! ${data.sold_properties} sold properties with ${data.sold_prices} price records. Refreshing display...`);
                    
                    console.log('🔄 Reloading properties from database...');
                    // Reload properties from database to get the sold data
                    await loadFromDatabaseOnStartup();
                    console.log('✅ Properties reloaded with sold data');
                } else {
                    console.warn('⚠️ Sold data import returned false success:', data.message);
                    showAlert('success', 'Properties loaded. Sold data will be available after background processing.');
                }
                
            } catch (error) {
                console.error('❌ Error importing sold data:', error);
                console.error('Error details:', error.message, error.stack);
                // Show error for debugging
                showAlert('error', `Sold data import failed: ${error.message}`);
            }
        }
        
        // Fetch ALL sold data for ALL properties (bulk import)
        async function fetchAllSoldData() {
            const fetchBtn = document.getElementById('fetchSoldBtn');
            if (!fetchBtn) return;
            
            fetchBtn.disabled = true;
            fetchBtn.innerHTML = `
                <svg class="sync-icon spinning" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                Fetching Sold Data...
            `;
            
            try {
                showAlert('success', 'Fetching sold data for ALL properties. This may take several minutes...');
                
                // Process in batches of 10 properties at a time
                const batchSize = 10;
                let processed = 0;
                let totalSold = 0;
                
                for (let i = 0; i < loadedProperties.length; i += batchSize) {
                    const batch = loadedProperties.slice(i, i + batchSize);
                    
                    for (const prop of batch) {
                        // Skip if already has sold data
                        if (prop.sold_properties && prop.sold_properties.length > 0) {
                            processed++;
                            continue;
                        }
                        
                        try {
                            const response = await fetch('/internal-properties/process-sold', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json',
                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                },
                                body: JSON.stringify({
                                    property_id: prop.id
                                })
                            });
                            
                            const data = await response.json();
                            
                            if (data.success && data.property) {
                                // Update local data
                                const idx = loadedProperties.findIndex(p => p.id == prop.id);
                                if (idx !== -1) {
                                    loadedProperties[idx] = data.property;
                                }
                                totalSold += data.sold_properties || 0;
                            }
                        } catch (err) {
                            console.error(`Error fetching sold data for property ${prop.id}:`, err);
                        }
                        
                        processed++;
                    }
                    
                    // Update progress
                    fetchBtn.innerHTML = `
                        <svg class="sync-icon spinning" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                        ${processed}/${loadedProperties.length} Done
                    `;
                    
                    // Small delay between batches
                    await new Promise(r => setTimeout(r, 500));
                }
                
                // Refresh display
                displayProperties(loadedProperties);
                
                showAlert('success', `✅ Sold data fetched! Found ${totalSold} sold records. Discount badges should now appear.`);
                
            } catch (error) {
                console.error('Error fetching all sold data:', error);
                showAlert('error', `Error: ${error.message}`);
            } finally {
                fetchBtn.disabled = false;
                fetchBtn.innerHTML = `
                    <svg class="sync-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Fetch All Sold Data (Step: 02)
                `;
            }
        }
        
        // Import ALL sold property history for a specific property
        async function importAllSoldHistory(event, propertyId, silentMode = false) {
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            const btn = document.getElementById(`header-import-${propertyId}`);
            if (btn && btn.disabled && !silentMode) return;
            
            // Show loading state
            if (btn) {
                btn.classList.add('loading');
                btn.disabled = true;
            }
            
            try {
                if (!silentMode) {
                    console.log(`📡 Importing all sold history for property ${propertyId}...`);
                    showAlert('success', 'Fetching complete sold history... this may take a moment.');
                }
                
                const response = await fetch('/internal-properties/process-sold', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        property_id: propertyId
                    })
                });
                
                const data = await response.json();
                
                if (!response.ok || !data.success) {
                    throw new Error(data.message || 'Failed to import sold history');
                }
                
                console.log(`✅ Sold history imported for property ${propertyId}`, data);
                showAlert('success', `Import complete! Processed ${data.sold_properties} sold records.`);
                
                // Update the property in the local loadedProperties array
                if (data.property) {
                    const propertyIndex = loadedProperties.findIndex(p => p.id == propertyId);
                    if (propertyIndex !== -1) {
                        loadedProperties[propertyIndex] = data.property;
                        // Re-render the card
                        updatePropertyCard(data.property);
                    }
                } else {
                    // Fallback to reload if property not returned (though it should be)
                    await loadFromDatabaseOnStartup();
                }
                
            } catch (error) {
                console.error(`❌ Error importing all sold history:`, error);
                showAlert('error', `Import failed: ${error.message}`);
            } finally {
                // Reset button state
                if (btn) {
                    btn.classList.remove('loading');
                    btn.disabled = false;
                }
            }
        }

        // Alert helper
        function showAlert(type, message) {

            const alert = type === 'success' ? successAlert : errorAlert;
            alert.textContent = message;
            alert.classList.add('active');
            
            setTimeout(() => {
                alert.classList.remove('active');
            }, 5000);
        }

        // Toggle Search URL edit mode
        function toggleSearchUrlEdit() {
            const urlDisplay = document.getElementById('searchUrlDisplay');
            const urlEdit = document.getElementById('searchUrlEdit');
            const urlInput = document.getElementById('searchUrlInput');
            
            if (urlDisplay && urlEdit) {
                urlDisplay.style.display = 'none';
                urlEdit.classList.add('active');
                urlInput.focus();
                urlInput.select();
            }
        }
        
        // Save Search URL
        async function saveSearchUrl() {
            const urlDisplay = document.getElementById('searchUrlDisplay');
            const urlEdit = document.getElementById('searchUrlEdit');
            const urlInput = document.getElementById('searchUrlInput');
            const urlLink = document.getElementById('searchUrlLink');
            const saveBtn = urlEdit.querySelector('.search-url-btn.save');
            
            const newUrl = urlInput.value.trim();
            
            if (!newUrl) {
                showAlert('error', 'URL cannot be empty');
                return;
            }
            
            // Disable save button while saving
            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.textContent = 'Saving...';
            }
            
            try {
                // Save to database if we have a search context
                if (window.searchContext && window.searchContext.id) {
                    const response = await fetch(`/searchproperties/update/${window.searchContext.id}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || ''
                        },
                        body: JSON.stringify({
                            updates_url: newUrl
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (!response.ok || !data.success) {
                        throw new Error(data.message || 'Failed to save URL');
                    }
                }
                
                // Update the displayed URL
                if (urlLink) {
                    urlLink.href = newUrl;
                    urlLink.textContent = newUrl;
                    urlLink.parentElement.title = newUrl;
                }
                
                // Update the search context for fetching properties
                if (window.searchContext) {
                    window.searchContext.updates_url = newUrl;
                }
                
                showAlert('success', 'Search URL updated successfully');
                
            } catch (error) {
                console.error('Error saving URL:', error);
                showAlert('error', 'Failed to save URL: ' + error.message);
            } finally {
                // Re-enable save button
                if (saveBtn) {
                    saveBtn.disabled = false;
                    saveBtn.textContent = 'Save';
                }
            }
            
            // Hide edit mode, show display mode
            urlEdit.classList.remove('active');
            urlDisplay.style.display = 'flex';
        }
        
        // Cancel Search URL edit
        function cancelSearchUrlEdit() {
            const urlDisplay = document.getElementById('searchUrlDisplay');
            const urlEdit = document.getElementById('searchUrlEdit');
            
            urlEdit.classList.remove('active');
            urlDisplay.style.display = 'flex';
        }
    </script>
@endsection
