<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\company_projects\laravel_projects\New folder\resources\views/layouts/footer.blade.php ENDPATH**/ ?>