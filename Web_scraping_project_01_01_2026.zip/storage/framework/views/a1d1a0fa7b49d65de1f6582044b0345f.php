<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
    </div>
</footer>
<?php /**PATH /home/mmmtapp/properties.mmmt.app/resources/views/layouts/footer.blade.php ENDPATH**/ ?>