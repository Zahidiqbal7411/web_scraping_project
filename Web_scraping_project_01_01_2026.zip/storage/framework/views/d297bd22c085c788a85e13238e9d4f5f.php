<nav class="navbar">
    <a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand"><?php echo e(config('app.name')); ?></a>
    <div class="navbar-user">
        <span class="user-name"><?php echo e(Auth::user() ? Auth::user()->name : 'Guest'); ?></span>
    </div>
</nav>
<?php /**PATH C:\Users\dell\Downloads\realmove-scraping\resources\views/layouts/header.blade.php ENDPATH**/ ?>